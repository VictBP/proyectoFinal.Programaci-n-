


package DAO;

import Entidades.Direccion;
import Entidades.Localidad;
import Entidades.Provincia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class DireccionDAO extends DAO {

    Connection cxn = null;
    Statement stm = null;
    ResultSet rs = null;
    String sql;

    public Direccion getDireccionxID(int id) { 

        Direccion dire = new Direccion();   

        try {

           
            sql = "SELECT * from tbdireccion WHERE IDDIRECCION = " + id;  
            cxn = this.getConexion();         
            stm = cxn.createStatement();       
            rs = stm.executeQuery(sql);        

       
            if (rs.first()) {
                dire.setIddireccion(rs.getInt(1));
                dire.setCalle(rs.getString(2));
                dire.setNumero(rs.getInt(3));
                dire.setPiso(rs.getInt(4));
                dire.setDepartamento(rs.getString(5));
                dire.setCp(rs.getString(6));
                LocalidadDAO localidad = new LocalidadDAO();
                dire.setLocalidad((Localidad) localidad.getLocalidadxID(rs.getDouble(7)));
                ProvinciaDAO provincia = new ProvinciaDAO();
                dire.setProvincia((Provincia) provincia.getProvinciaxID(rs.getInt(8)));

            }
            cxn.close();
            stm.close();
            rs.close();
            return dire;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar una direccion");
            return null;
        }

    }

    public int agregarDireccion(Direccion direccion) {
        PreparedStatement ps;
        int idGenerado = -1;
        try {
            sql = "INSERT into tbdireccion (iddireccion,calle,numero,piso,dpto,cp,idlocalidad,idprovincia) values (NULL,?,?,?,?,?,?,?)";
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, direccion.getCalle());
            ps.setInt(2, direccion.getNumero());
            ps.setInt(3, direccion.getPiso());
            ps.setString(4, direccion.getDepartamento());
            ps.setString(5, direccion.getCp());
            ps.setDouble(6, direccion.getLocalidad().getIdlocalidad());
            ps.setInt(7, direccion.getProvincia().getIdprovincia());
            ps.executeUpdate();

            ResultSet generatedKeys = ps.getGeneratedKeys();
            if (generatedKeys.next()) {
                idGenerado = generatedKeys.getInt(1);
            } else {
                System.out.println("Hubo un error al guardar la Direccion");
            };
            ps.close();
            cxn.close();
            ps.close();

        } catch (SQLException ex) {
            System.out.println("Fallo el insert en tbdireccion");
        }
    return idGenerado;
    }


}
