
package DAO;

import Entidades.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class UsuarioDAO extends DAO {
    
    Connection cxn = null;
    Statement stm = null;
    ResultSet rs = null;
    String sql;

    
    public boolean validarUsr(int usr, String pass) {

        sql = "SELECT * FROM tbusuarios WHERE DNI = '" + usr + "' and PASSWORD = '" + pass + "' and borrado <> true";
        boolean esok = false;
        System.out.println(usr);
        System.out.println(pass);

        try {
            cxn = this.getConexion();
            stm = cxn.createStatement();
            rs = stm.executeQuery(sql);
            System.out.println("Paso el loggin");

            if (rs.first()) {
                esok = true;
            }
            cxn.close();
            stm.close();
            rs.close();

        } catch (Exception e) {
            System.out.println("Error al conectar para loggin");
        }

        return esok;
    }

   
    public LinkedList<Usuario> getAllUsrs() { 

        LinkedList<Usuario> listaUsr = new LinkedList<Usuario>();

        try {

         
            sql = "SELECT * from tbusuarios WHERE borrado <> true";  
            cxn = this.getConexion();        
            stm = cxn.createStatement();       
            rs = stm.executeQuery(sql);       

           
            while (rs.next()) {
                Usuario usr = new Usuario();  
                usr.setIdusuario(rs.getInt(1));
                usr.setNombre(rs.getString(2));
                usr.setDNI(rs.getInt(3));
                usr.setPassword(rs.getString(4));
                listaUsr.add(usr);
            }
            System.out.println("Se lleno la lista de Usuarios del DAO");

            cxn.close();
            stm.close();
            rs.close();

            return listaUsr;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la lista de usuarios");
            return null;
        }

    }

    
    public boolean agregarUsr(Usuario usr) {
        PreparedStatement ps;
        try {
            sql = "INSERT into tbusuarios (idusuarios,nombre,dni,password,borrado) values (NULL,?,?,?,?)";
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
            ps.setString(1, usr.getNombre());
            ps.setInt(2, usr.getDNI());
            ps.setString(3, usr.getPassword());
            ps.setInt(4, 0);

            ps.executeUpdate();
            cxn.close();
            ps.close();
            return true;
        } catch (SQLException ex) {
            System.out.println("Fallo el insert en Usuarios");
            return false;
        }

    }

    
    public Usuario getUsuarioxID(int idusr) {
        Usuario usr = new Usuario();
        try {
            sql = "Select * from tbusuarios where idusuarios = " + idusr + " and borrado = false";
            cxn = this.getConexion();
            stm = cxn.createStatement();      
            rs = stm.executeQuery(sql);

            if (rs.first()) {
                usr.setIdusuario(rs.getInt(1));
                usr.setNombre(rs.getString(2));
                usr.setDNI(rs.getInt(3));
                usr.setPassword(rs.getString(4));
                usr.setBorrado(rs.getBoolean(5));

            } else {
                System.out.println("Fallo la busqueda del Usuario por ID");
            }

        } catch (Exception e) {
            System.out.println("Algo fallo al Buscar Usr por Id");
        }
        return usr;
    }


    public boolean deleteUsuario(int idusr) {
        boolean ok = false;
        PreparedStatement ps;
        try {
            sql = "Update tbusuarios set borrado = true where idusuarios = " + idusr;
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
            ps.executeUpdate();

            cxn.close();
            ps.close();
            return ok = true;
        } catch (SQLException ex) {
            System.out.println("Fallo el Borrado de Usuario");
        }
        return ok;
    }

  
    
     public boolean modificarUsr(Usuario usr) {
        PreparedStatement ps;
        int idusu = usr.getIdusuario();
         System.out.println(idusu);
        try {
            sql = "UPDATE tbusuarios SET nombre = ?,dni = ?,password = ?,borrado = ? WHERE idusuarios = " + usr.getIdusuario();
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
            ps.setString(1, usr.getNombre());
            ps.setInt(2, usr.getDNI());
            ps.setString(3, usr.getPassword());
            ps.setInt(4, 0);

            ps.executeUpdate();
            cxn.close();
            ps.close();
            return true;
        } catch (SQLException ex) {
            System.out.println("Fallo el Update del Usuario");
            return false;
        }

    }
    
    
}
