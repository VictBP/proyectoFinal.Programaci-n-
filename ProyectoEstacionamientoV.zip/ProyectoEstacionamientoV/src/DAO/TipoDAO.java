
package DAO;

import Entidades.Direccion;
import Entidades.Marca;
import Entidades.Tipo;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class TipoDAO extends DAO{
    
        Connection cxn = null;
    Statement stm = null;
    ResultSet rs = null;
    String sql;

    public LinkedList<Tipo> getAllTipos() {

        LinkedList<Tipo> listaTipos = new LinkedList<Tipo>();

        try {

            
            sql = "SELECT * from tbtipos";  
            cxn = this.getConexion();        
            stm = cxn.createStatement();       
            rs = stm.executeQuery(sql);        


            while (rs.next()) {
                Tipo tipo = new Tipo();
                tipo.setIdtipo(rs.getInt(1));
                tipo.setDescripcion(rs.getString(2));                      
                listaTipos.add(tipo);
            }
            System.out.println("Se lleno la lista del Marcas");

            cxn.close();
            stm.close();
            rs.close();

            return listaTipos;
        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la lista tipos");
            return null;
        }
    }
    
   public Tipo getTipoxID(int id) { 
        
        Tipo tipo = new Tipo();   
       
        try {

            
            sql = "SELECT * from tbtipos WHERE IDTIPO = " + id;  
            cxn = this.getConexion();          
            stm = cxn.createStatement();       
            rs = stm.executeQuery(sql);        

        
            if (rs.first()) {
                tipo.setIdtipo(rs.getInt(1));
                tipo.setDescripcion(rs.getString(2));
                
            }
            cxn.close();
            stm.close();
            rs.close();
            return tipo;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la tabla tipo");
            return null;
        }

    }   
}
