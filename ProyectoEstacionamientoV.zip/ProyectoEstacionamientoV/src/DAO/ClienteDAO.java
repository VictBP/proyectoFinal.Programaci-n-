
package DAO;

import Entidades.Cliente;
import Entidades.Direccion;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.LinkedList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.Date;
import java.text.DateFormat;

public class ClienteDAO extends DAO {

    Connection cxn = null;
    Statement stm = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql;

    public LinkedList<Cliente> getAllClientes() {
        LinkedList<Cliente> listaCli = new LinkedList<Cliente>();

        try {
          
            sql = "SELECT * from tbpersona";  
            cxn = this.getConexion();         
            stm = cxn.createStatement();      
            rs = stm.executeQuery(sql);        


            while (rs.next()) {
                Cliente cli = new Cliente();   
                cli.setIdpersona(rs.getInt(1));
                cli.setCuil(rs.getInt(2));
                cli.setNombre(rs.getString(3));
                cli.setApellido(rs.getString(4));
                cli.setF_nacim(rs.getDate(5));
                cli.setEmail(rs.getString(6));
                cli.setTelefono1(rs.getString(7));
                cli.setTelefono2(rs.getString(8));
                cli.setTelefono3(rs.getString(9));
                DireccionDAO direccion = new DireccionDAO(); 
                cli.setDireccion((Direccion) direccion.getDireccionxID(rs.getInt(10)));
                cli.setIddominio(rs.getInt(11));
                cli.setIdcochera(rs.getInt(12));
                listaCli.add(cli);
            }
            cxn.close();
            stm.close();
            rs.close();
            System.out.println("Se lleno la lista Cliente del DAO");
            return listaCli;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la lista de clientes");
            return null;
        }

    }

    
    public Cliente getClientexID(int id) { 

        Cliente cliente = new Cliente();  

        try {

            sql = "SELECT * from tbpersona WHERE IDpersona = " + id; 
            cxn = this.getConexion();                                     
            stm = cxn.createStatement();                                  
            rs = stm.executeQuery(sql);                                 


            if (rs.first()) {
                cliente.setIdpersona(rs.getInt(1));                       
                cliente.setCuil(rs.getInt(2));
                cliente.setNombre(rs.getString(3));
                cliente.setApellido(rs.getString(4));
                cliente.setF_nacim(rs.getDate(5));
                cliente.setEmail(rs.getString(6));
                cliente.setTelefono1(rs.getString(7));
                cliente.setTelefono2(rs.getString(8));
                cliente.setTelefono3(rs.getString(9));
                DireccionDAO direccion = new DireccionDAO();
                cliente.setDireccion(direccion.getDireccionxID(rs.getInt(10)));
                cliente.setIddominio(rs.getInt(11));
                cliente.setIdcochera(rs.getInt(12));
            }
            cxn.close();
            stm.close();
            rs.close();
            System.out.println("Se lleno el Cliente del DAO");

            return cliente;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar un Cliente");
            return null;
        }

    }

    public boolean agregarCliente(Cliente cli) {

        String fec;
      
        try {
            SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
            fec = formato.format(cli.getF_nacim());
        } catch (Exception ex) {
            System.out.println("error de Fecha" + ex);
            fec = null;
        }
        Date date = Date.valueOf(fec);

       
        try {
            sql = "INSERT into tbpersona (cuil,nombre,apellido,f_nacim,email,telefono1,telefono2,telefono3,iddireccion,iddominio,idcochera) values (?,?,?,?,?,?,?,?,?,?,?)";
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
           
            ps.setInt(1, cli.getCuil());
            ps.setString(2, cli.getNombre());
            ps.setString(3, cli.getApellido());
            ps.setDate(4, date);
            ps.setString(5, cli.getEmail());
            ps.setString(6, cli.getTelefono1());
            ps.setString(7, cli.getTelefono2());
            ps.setString(8, cli.getTelefono3());
            ps.setInt(9, cli.getDireccion().getIddireccion());
            ps.setInt(10, -2);
            ps.setInt(11, cli.getIdcochera()); 
            ps.executeUpdate();

            cxn.close();
            ps.close();
            return true;

        } catch (SQLException ex) {
            System.out.println("Fallo el insert en Clientes");
            System.out.println(cli);
            return false;
        }
    }

    public int getMaxIDPersona() {
        int maxid = -1;

        try {

            sql = "SELECT MAX(IDPERSONA) from tbpersona";
            cxn = this.getConexion();
            stm = cxn.createStatement();
            rs = stm.executeQuery(sql);
            rs.next();
            maxid = rs.getInt(1);

            cxn.close();
            stm.close();
            rs.close();
        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la lista de clientes");
        }

        return maxid;
    }

    public boolean ModificarCliente(Cliente cli) {
        PreparedStatement ps;
        String fec;
 
        try {
            SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
            fec = formato.format(cli.getF_nacim());
        } catch (Exception ex) {
            System.out.println("error de Fecha" + ex);
            fec = null;
        }
        Date date = Date.valueOf(fec);

        try {
            sql = "UPDATE tbpersona SET cuil=?,nombre = ?,apellido=?,f_nacim=?,email=?,telefono1=?,telefono2=?,telefono3=?,iddireccion=?,iddominio=?,idcochera=? WHERE idpersona = " + cli.getIdpersona();
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
            ps.setInt(1, cli.getCuil());
            ps.setString(2, cli.getNombre());
            ps.setString(3, cli.getApellido());
            ps.setDate(4, date);
            ps.setString(5, cli.getEmail());
            ps.setString(6, cli.getTelefono1());
            ps.setString(7, cli.getTelefono2());
            ps.setString(8, cli.getTelefono3());
            ps.setInt(9, cli.getDireccion().getIddireccion());
            ps.setInt(10, -2);
            ps.setInt(11, 988);

            ps.executeUpdate();
            cxn.close();
            ps.close();
            return true;
        } catch (SQLException ex) {
            System.out.println("Fallo el Update del Cliente");
            return false;
        }
    }
}
