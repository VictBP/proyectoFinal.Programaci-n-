
package DAO;

import Entidades.Registro;
import java.util.LinkedList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RegistroDAO extends DAO {
    
    Connection cxn = null;
    Statement stm = null;
    ResultSet rs = null;
    String sql;

    public LinkedList<Registro> getAllRegistros() { 
        LinkedList<Registro> listaRegistros = new LinkedList<Registro>();

        try {
           
            sql = "SELECT * from tbregistro";  
            cxn = this.getConexion();          
            stm = cxn.createStatement();       
            rs = stm.executeQuery(sql);        

            while (rs.next()) {
                Registro reg = new Registro();
                reg.setIdregistro(rs.getInt(1));
                reg.setPatente(rs.getString(2));
                reg.setTitular(rs.getString(3));
                reg.setFecha(rs.getDate(4));
                reg.setHora(rs.getTime(5));
                reg.setES(rs.getBoolean(6));
                listaRegistros.add(reg);
            }
            System.out.println("Se lleno la lista de Registros E/S del DAO");

            cxn.close();
            stm.close();
            rs.close();

            return listaRegistros;

        } catch (SQLException ex) {
            System.out.println("Suceso inesperado al llenar la lista de Registros");
            return null;
        }
    }
    
}
