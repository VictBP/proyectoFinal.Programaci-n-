package DAO;

import Entidades.Provincia;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class ProvinciaDAO extends DAO {

    Connection cxn = null;
    Statement stm = null;
    ResultSet rs = null;
    String sql;

    public Provincia getProvinciaxID(int id) { 

        Provincia prov = new Provincia();  
        
        try {
          
            sql = "SELECT * from tbprovincias WHERE idProvincia = " + id;  
            cxn = this.getConexion();        
            stm = cxn.createStatement();       
            rs = stm.executeQuery(sql);        
            
            
            if (rs.first()) {
                prov.setIdprovincia(rs.getInt(1));
                prov.setNombre(rs.getString(2));
                prov.setAbreviatura(rs.getString(3));
            }
            cxn.close();
            stm.close();
            rs.close();
           
            return prov;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar una Provincia");
            return null;
        }

    }

    public LinkedList<Provincia> getAllProvincias() {
        LinkedList<Provincia> listaProvincias = new LinkedList<>();

        try {
            sql = "SELECT * from tbprovincias order by nombre";  
            cxn = this.getConexion();        
            stm = cxn.createStatement();       
            rs = stm.executeQuery(sql);

            while (rs.next()) {
                Provincia provi = new Provincia();
                provi.setIdprovincia(rs.getInt(1));
                provi.setNombre(rs.getString(2));
                provi.setAbreviatura(rs.getString(3));
                listaProvincias.add(provi);

            }
            cxn.close();
            stm.close();
            rs.close();
            System.out.println("Se lleno la lista de Provincias del DAO");
            return listaProvincias;
        } catch (SQLException ex) {
             System.out.println("Algo fallo al cargar la lista de provincias"); 
            return null;
        }

    }

}
