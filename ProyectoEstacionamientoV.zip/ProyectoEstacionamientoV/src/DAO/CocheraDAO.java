package DAO;

import Entidades.Cochera;
import Entidades.Vehiculo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class CocheraDAO extends DAO {

    Connection cxn = null;
    Statement stm = null;
    ResultSet rs = null;
    String sql;

    public LinkedList<Cochera> getAllCocheras() {

        LinkedList<Cochera> lstCocheras = new LinkedList<Cochera>();
        VehiculoDAO vdao = new VehiculoDAO();

        try {

            sql = "SELECT * from tbcocheras where idvehiculo = 0";
            cxn = this.getConexion();
            stm = cxn.createStatement();
            rs = stm.executeQuery(sql);

            // meto los datos en el linkedList que tengo que devolver
            while (rs.next()) {
                Cochera cochera = new Cochera();
                cochera.setIdcochera(rs.getInt(1));
                cochera.setNumcochera(rs.getString(2));
                cochera.setOcupado(rs.getBoolean(3));
                cochera.setIdvehiculo(rs.getInt(4));
                lstCocheras.add(cochera);
            }
            System.out.println("Se lleno la lista de Cocheras");

            cxn.close();
            stm.close();
            rs.close();

            return lstCocheras;
        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la lista de Cocheras");
            return null;
        }
    }

    public boolean updCochera(Vehiculo vehiculo) {
        PreparedStatement ps;

        try {
            sql = "Update tbcocheras set ocupada = 1  WHERE idvehiculo = " + vehiculo.getIddominio();
            System.out.println(sql);
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
            ps.executeUpdate();
            cxn.close();
            ps.close();
            return true;

        } catch (SQLException ex) {
            System.out.println("Fallo el Modificar en CocheraUPD");
            return false;
        }
    }

    public boolean outCochera(Vehiculo vehiculo) {
        PreparedStatement ps;

        try {
            sql = "Update tbcocheras set ocupada = 0  WHERE idvehiculo = " + vehiculo.getIddominio();
            System.out.println(sql);
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
            ps.executeUpdate();
            cxn.close();
            ps.close();
            return true;

        } catch (SQLException ex) {
            System.out.println("Fallo el Modificar en Cocheraout");
            return false;
        }
    }
}
