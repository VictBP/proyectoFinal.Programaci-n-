
package DAO;

import Entidades.Marca;
import Entidades.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class MarcaDAO extends DAO {

    Connection cxn = null;
    Statement stm = null;
    ResultSet rs = null;
    String sql;

    public LinkedList<Marca> getAllMarcas() {

        LinkedList<Marca> listaMarcas = new LinkedList<Marca>();

        try {

          
            sql = "SELECT * from tbmarcas order by descripcion";  
            cxn = this.getConexion();        
            stm = cxn.createStatement();   
            rs = stm.executeQuery(sql);      

            
            while (rs.next()) {
                Marca marca = new Marca();   
                marca.setIdmarca(rs.getInt(1));
                marca.setDescripcion(rs.getString(2));                     
                listaMarcas.add(marca);
            }
            System.out.println("Se lleno la lista del Marcas");

            cxn.close();
            stm.close();
            rs.close();
            return listaMarcas;
            
        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la lista marcas");
            return null;
        }
    }

    public Marca getMarcaxID(int id) {
           
        try {
            sql = "SELECT * from tbmarcas WHERE IDMARCA = " + id;
            cxn = this.getConexion();
            stm = cxn.createStatement();
            rs = stm.executeQuery(sql);
            
            Marca marc = new Marca();
            if (rs.first()) {
                marc.setIdmarca(rs.getInt(1));
                marc.setDescripcion(rs.getString(2));

            }
            cxn.close();
            stm.close();
            rs.close();
            return marc;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar una marca");
            return null;
        }

    }

    public boolean agregarMarca(Marca marca) {
        PreparedStatement ps;

        try {
            sql = "INSERT into tbmarcas (idmarca,descripcion) values (NULL,?)";
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
            ps.setString(1, marca.getDescripcion());
            ps.executeUpdate();
            cxn.close();
            ps.close();
            return true;

        } catch (SQLException ex) {
            System.out.println("Fallo el insert en Marcas");
            System.out.println(marca);
            return false;
        }
    }

    public boolean modificarMarca(Marca marca) {
        PreparedStatement ps;
        int idmarca = marca.getIdmarca();
     
        try {
            sql = "UPDATE tbmarcas SET descripcion = ? WHERE idmarca = " + idmarca;
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
            ps.setString(1, marca.getDescripcion());
            ps.executeUpdate();
            cxn.close();
            ps.close();
            return true;
        } catch (SQLException ex) {
            System.out.println("Fallo el Update de la marca");
            return false;
        }

    }

}
