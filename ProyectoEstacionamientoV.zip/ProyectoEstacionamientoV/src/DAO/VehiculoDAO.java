
package DAO;

import Entidades.Cochera;
import Entidades.Vehiculo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import Entidades.Vehiculocc;

public class VehiculoDAO extends DAO {

    Connection cxn = null;
    Statement stm = null;
    ResultSet rs = null;
    String sql;

    public LinkedList<Vehiculo> getAllVehiculos() {
        LinkedList<Vehiculo> listaVehiculo = new LinkedList<>();

        try {

            sql = "SELECT * from tbvehiculo";  
            cxn = this.getConexion();          
            stm = cxn.createStatement();      
            rs = stm.executeQuery(sql);       

            
            TipoDAO tipodao = new TipoDAO();
            ColorDAO colordao = new ColorDAO();
            MarcaDAO marcadao = new MarcaDAO();
            ModeloDAO modelodao = new ModeloDAO();
            while (rs.next()) {
                Vehiculo vehiculo = new Vehiculo();

                vehiculo.setIddominio(rs.getInt(1));
                vehiculo.setPatente(rs.getString(2));
                vehiculo.setTipo(tipodao.getTipoxID(rs.getInt(3)));
                vehiculo.setColor(colordao.getcolorxID(rs.getInt(4)));
                vehiculo.setAnio(rs.getInt(5));
                vehiculo.setMarca(marcadao.getMarcaxID(rs.getInt(6)));
                vehiculo.setModelo(modelodao.getModeloxID(rs.getInt(7)));
                listaVehiculo.add(vehiculo);
            }
            System.out.println("Se lleno la lista vehiculos");

            cxn.close();
            stm.close();
            rs.close();

            return listaVehiculo;
        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la lista vehiculos");
            return null;
        }
    }

    public LinkedList<Vehiculocc> getAllVehiculosxIDpersona(int idper) {
        LinkedList<Vehiculocc> listaVehiculocc = new LinkedList<Vehiculocc>();

        try {
         
            sql = "select v.*, c.ncochera from tbvehiculo as v inner join tbcocheras c on v.iddominio= c.idvehiculo where v.idpersona = " + idper;
            cxn = this.getConexion();       
            stm = cxn.createStatement();    
            rs = stm.executeQuery(sql);        

            
            TipoDAO tipodao = new TipoDAO();
            ColorDAO colordao = new ColorDAO();
            MarcaDAO marcadao = new MarcaDAO();
            ModeloDAO modelodao = new ModeloDAO();
            while (rs.next()) {
                Vehiculocc vehiculocc = new Vehiculocc();
                vehiculocc.setIddominio(rs.getInt(1));
                vehiculocc.setPatente(rs.getString(2));
                vehiculocc.setTipo(tipodao.getTipoxID(rs.getInt(3)));
                vehiculocc.setColor(colordao.getcolorxID(rs.getInt(4)));
                vehiculocc.setAnio(rs.getInt(5));
                vehiculocc.setMarca(marcadao.getMarcaxID(rs.getInt(6)));
                vehiculocc.setModelo(modelodao.getModeloxID(rs.getInt(7)));
                vehiculocc.setIdpersona(rs.getInt(8));
                vehiculocc.setCochera(rs.getString(9));
                listaVehiculocc.add(vehiculocc);
            }
            System.out.println("Se lleno la lista vehiculos x cliente");

            cxn.close();
            stm.close();
            rs.close();
            return listaVehiculocc;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la lista vehiculos x cliente");
            return null;
        }
    }

    public Vehiculo getvehiculoxID(int id) {
        Vehiculo vehiculo = new Vehiculo();
        TipoDAO tipodao = new TipoDAO();
        ColorDAO colordao = new ColorDAO();
        MarcaDAO marcadao = new MarcaDAO();
        ModeloDAO modelodao = new ModeloDAO();

        try {
            sql = "SELECT * from tbvehiculo WHERE IDDOMINIO = " + id;
            cxn = this.getConexion();
            stm = cxn.createStatement();
            rs = stm.executeQuery(sql);

            if (rs.first()) {
                vehiculo.setIddominio(rs.getInt(1));
                vehiculo.setPatente(rs.getString(2));
                vehiculo.setTipo(tipodao.getTipoxID(rs.getInt(3)));
                vehiculo.setColor(colordao.getcolorxID(rs.getInt(4)));
                vehiculo.setAnio(rs.getInt(5));
                vehiculo.setMarca(marcadao.getMarcaxID(rs.getInt(6)));
                vehiculo.setModelo(modelodao.getModeloxID(rs.getInt(7)));
                System.out.println("se lleno el vehiculo");

            }
            cxn.close();
            stm.close();
            rs.close();
            return vehiculo;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar un vehiculo");
            return null;
        }

    }

    public Vehiculo getvehiculoxPatente(String pat) {
        System.out.println(pat);
        Vehiculo vehiculo = new Vehiculo();
        TipoDAO tipodao = new TipoDAO();
        ColorDAO colordao = new ColorDAO();
        MarcaDAO marcadao = new MarcaDAO();
        ModeloDAO modelodao = new ModeloDAO();

        try {
            sql = "SELECT * from tbvehiculo WHERE PATENTE = " + "'" + pat + "'";
            cxn = this.getConexion();
            stm = cxn.createStatement();
            rs = stm.executeQuery(sql);

            System.out.println(sql);
            if (rs.first()) {
                vehiculo.setIddominio(rs.getInt(1));
                vehiculo.setPatente(rs.getString(2));
                vehiculo.setTipo(tipodao.getTipoxID(rs.getInt(3)));
                vehiculo.setColor(colordao.getcolorxID(rs.getInt(4)));
                vehiculo.setAnio(rs.getInt(5));
                vehiculo.setMarca(marcadao.getMarcaxID(rs.getInt(6)));
                vehiculo.setModelo(modelodao.getModeloxID(rs.getInt(7)));
                vehiculo.setIdpersona(rs.getInt(8));
                System.out.println("se lleno el vehiculo x Patente");

            }
            cxn.close();
            stm.close();
            rs.close();
            return vehiculo;

        } catch (SQLException ex) {
            System.out.println(ex);
            System.out.println("algo paso al llenar un vehiculo x Patente");
            return null;
        }

    }

   
    public boolean agregarVehiculo(Vehiculo vehiculo, Cochera cochera) {
        PreparedStatement ps;
        int idgenerado = 0;
        try {
            sql = "INSERT into tbvehiculo (PATENTE,IDTIPO,IDCOLOR,ANIO,IDMARCA,IDMODELO,IDPERSONA) VALUES (?,?,?,?,?,?,?)";
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, vehiculo.getPatente());
            ps.setInt(2, vehiculo.getTipo().getIdtipo());
            ps.setInt(3, vehiculo.getColor().getIdcolor());
            ps.setInt(4, vehiculo.getAnio());
            ps.setInt(5, vehiculo.getMarca().getIdmarca());
            ps.setInt(6, vehiculo.getModelo().getIdmodelo());
            ps.setInt(7, vehiculo.getIdpersona());
            ps.executeUpdate();
            
            ps.getGeneratedKeys();
            ResultSet generatedKey = ps.getGeneratedKeys();
            if (generatedKey.next()) {
                idgenerado = generatedKey.getInt(1);
            } else {
                System.out.println("Hubo un error al obtener el idcochera");
            };
            ps.close();
           
        } catch (SQLException ex) {
            System.out.println("Fallo el insert en Vehiculo");
            return false;

        }

        try {
            sql = "";
            ps = null;
            sql = "UPDATE tbcocheras SET ocupada = ?,idvehiculo = ? WHERE idcocheras = " + cochera.getIdcochera();
         
            ps = cxn.prepareStatement(sql);
            ps.setBoolean(1, true);
            ps.setInt(2, idgenerado);
            ps.executeUpdate();
            cxn.close();
            ps.close();
            return true;

        } catch (SQLException ex) {
            System.out.println("Fallo el insert en Cochera");
            return false;
        }
    }

     
    public boolean modificarVehiculo(Vehiculo vehiculo) {
        PreparedStatement ps;

        try {
            sql = "Update tbvehiculo set PATENTE = ?,IDTIPO = ?, IDCOLOR = ?, ANIO = ? ,IDMARCA = ?, IDMODELO = ?  WHERE IDDOMINIO = " + vehiculo.getIddominio();
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);

            ps.setString(1, vehiculo.getPatente());
            ps.setInt(2, vehiculo.getTipo().getIdtipo());
            ps.setInt(3, vehiculo.getColor().getIdcolor());
            ps.setInt(4, vehiculo.getAnio());
            ps.setInt(5, vehiculo.getMarca().getIdmarca());
            ps.setInt(6, vehiculo.getModelo().getIdmodelo());
            ps.executeUpdate();

            cxn.close();
            ps.close();
            return true;

        } catch (SQLException ex) {
            System.out.println("Fallo el Modificar en Vehiculo");
            return false;
        }
    }
       

    public boolean deleteVehiculo(int idVehiculo) {
        boolean ok = false;
        PreparedStatement ps;
        try {
            sql = "DELETE from tbvehiculo where iddominio = " + idVehiculo;
            cxn = this.getConexion();
            stm = cxn.createStatement();       
            stm.executeUpdate(sql);

            cxn.close();
            stm.close();
            return ok = true;
        } catch (SQLException ex) {
            System.out.println("Fallo el Borrado de Vehiculo");
        }
        return ok;
    }

}
