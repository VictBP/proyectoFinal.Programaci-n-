package DAO;

import Entidades.Color;
import Entidades.Marca;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class ColorDAO extends DAO { 

    Connection cxn = null;
    Statement stm = null;
    ResultSet rs = null;
    String sql;

    public LinkedList<Color> getAllColores() {
        LinkedList<Color> listaColor = new LinkedList<Color>();

        try {

        
            sql = "SELECT * from tbcolores"; 
            cxn = this.getConexion();        
            stm = cxn.createStatement();    
            rs = stm.executeQuery(sql);        

           
            while (rs.next()) {
                Color color = new Color();
                color.setIdcolor(rs.getInt(1));
                color.setDescripcion(rs.getString(2));
                listaColor.add(color);
            }
            System.out.println("Se lleno la lista colores");

            cxn.close();
            stm.close();
            rs.close();

            return listaColor;
        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la lista colores");
            return null;
        }
    }

    public Color getcolorxID(int id) {
        Connection cxn = null;
        Statement stm = null;
        ResultSet rs = null;
        String sql;
        Color color = new Color();
        try {

            sql = "SELECT * from tbcolores WHERE IDCOLOR = " + id;
            cxn = this.getConexion();
            stm = cxn.createStatement();
            rs = stm.executeQuery(sql);

            if (rs.first()) {
                color.setIdcolor(rs.getInt(1));
                color.setDescripcion(rs.getString(2));
            }
            cxn.close();
            stm.close();
            rs.close();
            return color;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar un color");
            return null;
        }

    }

    public boolean agregarColor(Color color) {
        PreparedStatement ps;

        try {
            sql = "INSERT into tbcolores (idcolor,descripcion) values (NULL,?)";
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
            ps.setString(1, color.getDescripcion());
            ps.executeUpdate();
            cxn.close();
            ps.close();
            return true;

        } catch (SQLException ex) {
            System.out.println("Fallo el insert de color");
            System.out.println(color);
            return false;
        }
    }

    public boolean modificarColor(Color color) {
        PreparedStatement ps;
        int idcolor = color.getIdcolor();

        try {
            sql = "UPDATE tbcolores SET descripcion = ? WHERE idcolor = " + idcolor;
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
            ps.setString(1, color.getDescripcion());
            ps.executeUpdate();
            cxn.close();
            ps.close();
            return true;
        } catch (SQLException ex) {
            System.out.println("Fallo el Update del color");
            return false;
        }
    }

}
