
package DAO;

import Entidades.Modelo;
import DAO.MarcaDAO;
import Entidades.Marca;
import Entidades.Tipo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;


public class ModeloDAO extends DAO{
    
    Connection cxn = null;
    Statement stm = null;
    ResultSet rs = null;
    String sql;

    public LinkedList<Modelo> getAllModelos() { 
        LinkedList<Modelo> listaModelos = new LinkedList<Modelo>();

        try {
           
            sql = "SELECT * from tbmodelos";  
            cxn = this.getConexion();         
            stm = cxn.createStatement();      
            rs = stm.executeQuery(sql);     

           
            while (rs.next()) {
                Modelo mod = new Modelo();
                mod.setIdmodelo(rs.getInt(1));
                MarcaDAO marcadao = new MarcaDAO();
                mod.setMarca(marcadao.getMarcaxID(rs.getInt(2)));
                mod.setDescripcion(rs.getString(3));
                TipoDAO tipodao = new TipoDAO();
                mod.setTipo(tipodao.getTipoxID(rs.getInt(4)));
                listaModelos.add(mod);
            }
            System.out.println("Se lleno la lista de Modelos del DAO");

            cxn.close();
            stm.close();
            rs.close();

            return listaModelos;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la lista de usuarios");
            return null;
        }
    }

    public LinkedList<Modelo> getAllModelosCmb() { 
        Marca marca = null;
        Tipo tipo = null;
        LinkedList<Modelo> listaModelos = new LinkedList<Modelo>();

        try {
            
            sql = "SELECT * from tbmodelos";  
            cxn = this.getConexion();         
            stm = cxn.createStatement();       
            rs = stm.executeQuery(sql);      

           
            while (rs.next()) {
                Modelo mod = new Modelo();
                mod.setIdmodelo(rs.getInt(1));
                mod.setMarca(marca);
                mod.setDescripcion(rs.getString(3));
                mod.setTipo(tipo);
                listaModelos.add(mod);
            }
            System.out.println("Se lleno la lista de Modelos del DAO");

            cxn.close();
            stm.close();
            rs.close();

            return listaModelos;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la lista de usuarios");
            return null;
        }
    }

    public Modelo getModeloxID(int id) {

        Modelo modelo = new Modelo();

        MarcaDAO marcadao = new MarcaDAO();
        Marca marca = marcadao.getMarcaxID(id);
        TipoDAO tipodao = new TipoDAO();
        Tipo tipo = tipodao.getTipoxID(marca.getIdmarca());

        try {

           
            sql = "SELECT * from tbmodelos WHERE IDMODELO = " + id;  
            cxn = this.getConexion();          
            stm = cxn.createStatement();       
            rs = stm.executeQuery(sql);        


            if (rs.first()) {
                modelo.setIdmodelo(rs.getInt(1));
                modelo.setMarca(marca);
                modelo.setDescripcion(rs.getString(3));
                modelo.setTipo(tipo);

            }
            cxn.close();
            stm.close();
            rs.close();
            return modelo;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la tabla tipo");
            return null;
        }

    }

    public LinkedList<Modelo> getAllModelosxMarca(int idMarca) {

        LinkedList<Modelo> listaModelos = new LinkedList<Modelo>();
        MarcaDAO marcadao = new MarcaDAO();
        Marca marca = marcadao.getMarcaxID(idMarca);
        TipoDAO tipodao = new TipoDAO();
        Tipo tipo = tipodao.getTipoxID(marca.getIdmarca());

        try {

         
            sql = "SELECT * from tbmodelos where idmarca = " + idMarca;  
            cxn = this.getConexion();          
            stm = cxn.createStatement();     
            rs = stm.executeQuery(sql);       

  
            while (rs.next()) {
                Modelo mod = new Modelo();
                mod.setIdmodelo(rs.getInt(1));
                mod.setMarca(marca);
                mod.setDescripcion(rs.getString(3));
                mod.setTipo(tipo);
                listaModelos.add(mod);
            }
            System.out.println("Se lleno la lista de Modelos x idMarca del DAO");

            cxn.close();
            stm.close();
            rs.close();

            return listaModelos;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar la lista de Modelos");
            return null;
        }
        
    }

 public boolean agregarModelo(Modelo modelo) {
        PreparedStatement ps;

        try {
            sql = "INSERT into tbmodelos (idmodelo,idmarca,descripcion,idtipo) values (NULL,?,?,?)";
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
            
            ps.setInt(1, modelo.getMarca().getIdmarca());
            ps.setString(2, modelo.getDescripcion());
            ps.setInt(3, modelo.getTipo().getIdtipo());

            ps.executeUpdate();
            cxn.close();
            ps.close();
            return true;

        } catch (SQLException ex) {
            System.out.println("Fallo el insert en Modelos");
            System.out.println(ex);
            return false;
        }
    }

    public boolean modificarModelo(Modelo modelo) {
        PreparedStatement ps;
        int idmodelo = modelo.getIdmodelo();
      
        try {
            sql = "Update tbmodelos set DESCRIPCION = ?,IDMARCA = ?, IDTIPO = ? WHERE IDMODELO = " + modelo.getIdmodelo();
            cxn = this.getConexion();
            ps = cxn.prepareStatement(sql);
            ps.setInt(2, modelo.getMarca().getIdmarca());
            ps.setString(1, modelo.getDescripcion());
            ps.setInt(3, modelo.getTipo().getIdtipo());
            ps.executeUpdate();
            cxn.close();
            ps.close();
            return true;
        } catch (SQLException ex) {
            System.out.println("Fallo el Update del modelo");
            return false;
        }
    }
    public boolean deleteModelo(int idmodelo) {
        boolean ok = false;
        PreparedStatement ps;
        try {
            sql = "DELETE from tbmodelos where idmodelo = " + idmodelo;
            cxn = this.getConexion();
            stm = cxn.createStatement();       
            stm.executeUpdate(sql);

            cxn.close();
            stm.close();
            return ok = true;
        } catch (SQLException ex) {
            System.out.println("Fallo el Borrado de Vehiculo");
        }
        return ok;
    }    
    
}
