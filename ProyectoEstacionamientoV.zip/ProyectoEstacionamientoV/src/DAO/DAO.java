
package DAO;

import Managers.CofingManager;
import java.sql.Connection;

public class DAO {
      private String getConexionURL() {

        return "jdbc:mysql://" + CofingManager.host + ":" + CofingManager.port + "/" + CofingManager.db;
    }
     
    public Connection getConexion() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = java.sql.DriverManager.getConnection(getConexionURL(), CofingManager.usr, CofingManager.pwd);

            if (conn != null) {
                System.out.println("La conexión a la base se genero exitosamente");
                return conn;
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error de seguimiento en getconnection():" + e.getMessage());

        }
        return null;
    }
}
