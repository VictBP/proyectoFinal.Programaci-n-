
package DAO;

import Entidades.Direccion;
import Entidades.Localidad;
import Entidades.Provincia;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class LocalidadDAO extends DAO {

    Connection cxn = null;
    Statement stm = null;
    ResultSet rs = null;
    String sql;

    public Localidad getLocalidadxID(Double id) {
        Localidad loca = new Localidad();
        try {

          
            sql = "SELECT * from tblocalidades WHERE idLocalidad = " + id; 
            cxn = this.getConexion();                                    
            stm = cxn.createStatement();                                 
            rs = stm.executeQuery(sql);                                  

            
            if (rs.first()) {

                loca.setIdlocalidad(rs.getDouble(1));
                loca.setNombre(rs.getString(2));
                loca.setNombre(rs.getString(3));
                ProvinciaDAO provincia = new ProvinciaDAO();   
                loca.setProvincia((Provincia) provincia.getProvinciaxID(rs.getInt(4)));

            }

            cxn.close();
            stm.close();
            rs.close();
            System.out.println("Se lleno la Localidad del DAO");
            return loca;

        } catch (SQLException ex) {
            System.out.println("algo paso al llenar una Localidad");
            return null;
        }

    }

    public LinkedList<Localidad> getAllLocalidades() {
        LinkedList<Localidad> listaLocalidad = new LinkedList<>();
        Provincia p = null;
        try {
            sql = "SELECT * from tblocalidades order by nombre";  
            cxn = this.getConexion();          
            stm = cxn.createStatement();       
            rs = stm.executeQuery(sql);

            while (rs.next()) {
                Localidad local = new Localidad();
                local.setIdlocalidad(rs.getDouble(1));
                local.setNombre(rs.getString(2));  
                local.setDepartamento(rs.getString(3));
                local.setProvincia(p);
                listaLocalidad.add(local);

            }
            cxn.close();
            stm.close();
            rs.close();
            System.out.println("Se lleno la lista de Localidades del DAO");
            return listaLocalidad;
        } catch (SQLException ex) {
            System.out.println("Algo fallo al cargar la lista de Localidades");
            return null;
        }

    }

    public LinkedList<Localidad> getAllLocalidadesxIDProvincia(int idbuscado) {
        LinkedList<Localidad> listaLocalidad = new LinkedList<>();
        ProvinciaDAO provincia = new ProvinciaDAO();
        Provincia provi = provincia.getProvinciaxID(idbuscado); 

        try {
            sql = "SELECT * from tblocalidades where id_provincia = " + idbuscado + " order by nombre";  // escribo la sentencia que necesito para obtener los datos
            cxn = this.getConexion();         
            stm = cxn.createStatement();       
            rs = stm.executeQuery(sql);

            while (rs.next()) {
                Localidad local = new Localidad();
                local.setIdlocalidad(rs.getDouble(1));
                local.setNombre(rs.getString(2));
                local.setDepartamento(rs.getString(3)); 
                local.setProvincia(provi);
                listaLocalidad.add(local);
            }
            cxn.close();
            stm.close();
            rs.close();
            System.out.println("Se lleno la lista de Localidades del DAO");
            return listaLocalidad;
        } catch (SQLException ex) {
            System.out.println("Algo fallo al cargar la lista de Localidades combo");
            return null;
        }

    }

}
