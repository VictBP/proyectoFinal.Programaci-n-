package GUI;

import DAO.CocheraDAO;
import Entidades.Cochera;
import java.util.LinkedList;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class CocheraGUI extends javax.swing.JDialog {

    public CocheraGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        mostrarCocheras();
    }

    private void mostrarCocheras() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Id cochera");
        modelo.addColumn("Número cochera");
        modelo.addColumn("Ocupado");

        Cochera cochera = new Cochera();
        CocheraDAO cocheradao = new CocheraDAO();
        LinkedList<Cochera> listaCocheras = new LinkedList<Cochera>();
        listaCocheras = cocheradao.getAllCocheras();

        Object[] datos = new Object[3];
        for (Cochera dato : listaCocheras) {
            datos[0] = dato.getIdcochera();
            datos[1] = dato.getNumcochera();
            datos[2] = dato.isOcupado();
            modelo.addRow(datos);
        }
        tablaCochera.setModel(modelo);
        TableColumn col = tablaCochera.getColumnModel().getColumn(0);
        TableColumn col1 = tablaCochera.getColumnModel().getColumn(1);
        TableColumn col2 = tablaCochera.getColumnModel().getColumn(2);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaCochera = new javax.swing.JTable();
        etiquetaCodigo = new javax.swing.JLabel();
        etiquetaDescripcion = new javax.swing.JLabel();
        botonSalir = new javax.swing.JButton();
        campoId = new javax.swing.JTextField();
        campoCodigo = new javax.swing.JTextField();
        campoDescripcion = new javax.swing.JTextField();

        setUndecorated(true);

        tablaCochera.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaCochera.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaCocheraMouseClicked(evt);
            }
        });
        tablaCochera.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tablaCocheraKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tablaCochera);

        etiquetaCodigo.setText("Codigo:");

        etiquetaDescripcion.setText("Descripcion:");

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 499, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(etiquetaCodigo)
                        .addGap(12, 12, 12)
                        .addComponent(campoId, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(campoCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(etiquetaDescripcion)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(campoDescripcion)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonSalir)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaCodigo)
                    .addComponent(campoId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaDescripcion)
                    .addComponent(campoDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(botonSalir)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
        dispose(); 
    }//GEN-LAST:event_botonSalirActionPerformed

    private void tablaCocheraKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tablaCocheraKeyPressed
        Cochera cochera = new Cochera();
        CocheraDAO cocheradao = new CocheraDAO();
        int idcochera = Integer.parseInt(tablaCochera.getValueAt(tablaCochera.getSelectedRow(), 0).toString());

       // cochera = cocheradao.getcocheraxID(idcochera);

        campoId.setText(String.valueOf(cochera.getIdcochera()));
        //txtDescripcion.setText(cochera.getNumcochera()));
    }//GEN-LAST:event_tablaCocheraKeyPressed

    private void tablaCocheraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaCocheraMouseClicked
        Cochera cochera = new Cochera();
        CocheraDAO cocheradao = new CocheraDAO();
        int idcochera = Integer.parseInt(tablaCochera.getValueAt(tablaCochera.getSelectedRow(), 0).toString());
        //System.out.println(idauto);
        /*
        campoId.setText(String.valueOf(cochera.getIdcochera()));
        
        if(cochera.isOcupado())
            campoDescripcion.setText("Num: "+cochera.getNumcochera()+", Ocupado: sí");
        else
            campoDescripcion.setText("Num: "+cochera.getNumcochera()+", Ocupado: no");
        //txtDescripcion.setText(cochera.getNumcochera()));
        */
    }//GEN-LAST:event_tablaCocheraMouseClicked

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonSalir;
    private javax.swing.JTextField campoCodigo;
    private javax.swing.JTextField campoDescripcion;
    private javax.swing.JTextField campoId;
    private javax.swing.JLabel etiquetaCodigo;
    private javax.swing.JLabel etiquetaDescripcion;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaCochera;
    // End of variables declaration//GEN-END:variables
}
