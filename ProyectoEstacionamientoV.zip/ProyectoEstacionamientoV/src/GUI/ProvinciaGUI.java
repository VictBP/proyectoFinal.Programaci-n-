package GUI;

import DAO.ProvinciaDAO;
import Entidades.Provincia;
import java.util.LinkedList;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class ProvinciaGUI extends javax.swing.JDialog {

    public ProvinciaGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
       mostrarProvincias();
    }

   private void mostrarProvincias() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Id Pronvia");
        modelo.addColumn("Nombre");

        Provincia prov = new Provincia(); 
        ProvinciaDAO provinciadao = new ProvinciaDAO();
        LinkedList<Provincia> listaProvincias = new LinkedList<>();
        listaProvincias =  provinciadao.getAllProvincias();

        Object[] datos = new Object[2];
        for (Provincia dato : listaProvincias) {
            datos[0] = dato.getIdprovincia();
            datos[1] = dato.getNombre();  
            modelo.addRow(datos);
        }
        tablaProvincia.setModel(modelo);
        TableColumn col = tablaProvincia.getColumnModel().getColumn(0);
        TableColumn col2 = tablaProvincia.getColumnModel().getColumn(1);
    }
       
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaProvincia = new javax.swing.JTable();
        botonSalir = new javax.swing.JButton();
        etiquetaCodigo = new javax.swing.JLabel();
        etiquetaDescripcion = new javax.swing.JLabel();
        campoDescripcion = new javax.swing.JTextField();
        campoId = new javax.swing.JTextField();
        campoCodigo = new javax.swing.JTextField();

        setUndecorated(true);

        tablaProvincia.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaProvincia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaProvinciaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaProvincia);

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        etiquetaCodigo.setText("Codigo:");

        etiquetaDescripcion.setText("Descripcion:");

        campoDescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoDescripcionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonSalir)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(etiquetaCodigo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(campoId, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(campoCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(etiquetaDescripcion)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(campoDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaCodigo)
                    .addComponent(campoId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaDescripcion)
                    .addComponent(campoDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(botonSalir)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void campoDescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoDescripcionActionPerformed
        
    }//GEN-LAST:event_campoDescripcionActionPerformed

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
        dispose();
    }//GEN-LAST:event_botonSalirActionPerformed

    private void tablaProvinciaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaProvinciaMouseClicked
        Provincia proV = new Provincia();
        ProvinciaDAO proD = new ProvinciaDAO();
        int IdProvincia = Integer.parseInt(tablaProvincia.getValueAt(tablaProvincia.getSelectedRow(),0).toString());
        
        proV = proD.getProvinciaxID(IdProvincia);
        
        campoId.setText(String.valueOf(proV.getIdprovincia()));
        campoId.setText(proV.getNombre());
    }//GEN-LAST:event_tablaProvinciaMouseClicked

 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonSalir;
    private javax.swing.JTextField campoCodigo;
    private javax.swing.JTextField campoDescripcion;
    private javax.swing.JTextField campoId;
    private javax.swing.JLabel etiquetaCodigo;
    private javax.swing.JLabel etiquetaDescripcion;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaProvincia;
    // End of variables declaration//GEN-END:variables
}
