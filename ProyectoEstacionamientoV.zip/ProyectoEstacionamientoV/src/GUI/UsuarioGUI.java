
package GUI;

import DAO.UsuarioDAO;
import Entidades.Usuario;
import java.awt.Color;
import java.awt.Font;
import java.util.LinkedList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.tree.DefaultTreeModel;

public class UsuarioGUI extends javax.swing.JDialog {

    private boolean modificar = false;
    
    public UsuarioGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        mostrarUsuarios();
        inicializarComponentes(false);
        botonGuardar.setEnabled(false);
        botonEliminar.setEnabled(false);
        botonModificar.setEnabled(false);

      
    }

    
    void inicializarComponentes(boolean b) {
        campoUsuario.setEnabled(b);
        TextPrompt prompcampoUsuario = new TextPrompt("Ingrese el Nombre del Usuario (solo letras)", campoUsuario);
        prompcampoUsuario.setForeground(Color.LIGHT_GRAY);
        prompcampoUsuario.changeAlpha(0.7f);
        prompcampoUsuario.changeStyle(Font.LAYOUT_LEFT_TO_RIGHT + Font.ROMAN_BASELINE + Font.ITALIC);
        campoUsuario.setText("");

        TextPrompt prompcampoDni = new TextPrompt("Ingrese el DNI del Usuario (solo Números)", campoDni);
        prompcampoDni.setForeground(Color.pink);
        prompcampoDni.changeAlpha(0.7f);
        prompcampoDni.changeStyle(Font.LAYOUT_LEFT_TO_RIGHT + Font.ROMAN_BASELINE + Font.ITALIC);
        campoDni.setEnabled(b);
        campoDni.setText("");

        campoContraseña.setEnabled(b);
    }
    
    private void mostrarUsuarios() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Id del Usuario");
        modelo.addColumn("Nombre de Usuario");
        modelo.addColumn("D.N.I");
        modelo.addColumn("Pass");

        UsuarioDAO usrdao = new UsuarioDAO();
        LinkedList<Usuario> lista = new LinkedList<Usuario>();
        lista = usrdao.getAllUsrs();

        Object[] datos = new Object[4];
        for (Usuario dato : lista) {
            datos[0] = dato.getIdusuario();
            datos[1] = dato.getNombre();
            datos[2] = dato.getDNI();
            datos[3] = dato.getPassword();
            modelo.addRow(datos);
        }
        tablaUsuarios.setModel(modelo);
        TableColumn columna1 = tablaUsuarios.getColumnModel().getColumn(0);
        TableColumn columna2 = tablaUsuarios.getColumnModel().getColumn(1);
        TableColumn columna3 = tablaUsuarios.getColumnModel().getColumn(2);
        TableColumn columna4 = tablaUsuarios.getColumnModel().getColumn(3);
        columna4.setMinWidth(0);
        columna4.setMaxWidth(0);
        columna4.setResizable(false);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaUsuarios = new javax.swing.JTable();
        etiquetaUsuario = new javax.swing.JLabel();
        etiquetaDNI = new javax.swing.JLabel();
        etiquetaContraseña = new javax.swing.JLabel();
        campoUsuario = new javax.swing.JTextField();
        campoDni = new javax.swing.JTextField();
        botonEliminar = new javax.swing.JButton();
        botonGuardar = new javax.swing.JButton();
        botonModificar = new javax.swing.JButton();
        botonAgregar = new javax.swing.JButton();
        botonSalir = new javax.swing.JButton();
        campoContraseña = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        tablaUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaUsuariosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaUsuarios);

        etiquetaUsuario.setText("Usuario");

        etiquetaDNI.setText("DNI");

        etiquetaContraseña.setText("Contraseña");

        campoUsuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campoUsuarioKeyTyped(evt);
            }
        });

        campoDni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoDniActionPerformed(evt);
            }
        });
        campoDni.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campoDniKeyTyped(evt);
            }
        });

        botonEliminar.setText("Eliminar");
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });

        botonGuardar.setText("Guardar");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonModificar.setText("Modificar");
        botonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonModificarActionPerformed(evt);
            }
        });

        botonAgregar.setText("Agregar");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        campoContraseña.setText("jPasswordField1");
        campoContraseña.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                campoContraseñaFocusGained(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 561, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(10, 10, 10)
                                    .addComponent(etiquetaDNI, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addComponent(etiquetaUsuario, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addComponent(etiquetaContraseña))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(campoDni, javax.swing.GroupLayout.DEFAULT_SIZE, 386, Short.MAX_VALUE)
                            .addComponent(campoUsuario)
                            .addComponent(campoContraseña))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(botonAgregar)
                                .addGap(18, 18, 18)
                                .addComponent(botonModificar)
                                .addGap(18, 18, 18)
                                .addComponent(botonGuardar)
                                .addGap(18, 18, 18)
                                .addComponent(botonEliminar))
                            .addComponent(botonSalir, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoDni, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(etiquetaDNI, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(etiquetaContraseña, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                    .addComponent(campoContraseña))
                .addGap(49, 49, 49)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonEliminar)
                    .addComponent(botonGuardar)
                    .addComponent(botonModificar)
                    .addComponent(botonAgregar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addComponent(botonSalir)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void campoDniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoDniActionPerformed
       
    }//GEN-LAST:event_campoDniActionPerformed

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
      dispose(); 
    }//GEN-LAST:event_botonSalirActionPerformed

    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        if (campoUsuario.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Debe ingresar un Nombre valido");
            campoUsuario.requestFocus();
            return;
        }
        if (campoDni.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Debe ingresar un DNI valido");
            campoDni.requestFocus();
            return;
        }

        UsuarioDAO udao = new UsuarioDAO();
        Usuario usr = new Usuario();
        usr.setNombre(campoUsuario.getText().trim().toUpperCase());   
        usr.setDNI(Integer.parseInt(campoDni.getText()));             
        usr.setPassword(campoContraseña.getText());
        
        if (modificar) {
            usr.setIdusuario(Integer.parseInt(tablaUsuarios.getValueAt(tablaUsuarios.getSelectedRow(), 0).toString()));
            if (udao.modificarUsr(usr)) {
                JOptionPane.showMessageDialog(rootPane, "El Usuario fue Modificado con exito");
                mostrarUsuarios();
                inicializarComponentes(false);
                botonGuardar.setEnabled(false);
                botonAgregar.setEnabled(true);
                modificar = false;   
            } else {
                System.out.println("fallo algo al Modificar el Usuario");
            }
        } else {         
            if (udao.agregarUsr(usr)) {
                mostrarUsuarios();
                JOptionPane.showMessageDialog(rootPane, "El Usuario fue Ingresado con exito");
                inicializarComponentes(false);
                botonGuardar.setEnabled(false);
                botonAgregar.setEnabled(true);
            } else {
                System.out.println("fallo algo");
            }
        }
         
    }//GEN-LAST:event_botonGuardarActionPerformed

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        botonGuardar.setEnabled(true);
        botonAgregar.setEnabled(false);
        inicializarComponentes(true);
    }//GEN-LAST:event_botonAgregarActionPerformed

    private void campoUsuarioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoUsuarioKeyTyped
        char valido = evt.getKeyChar();
        if (Character.isDigit(valido)) {
            evt.consume();
            JOptionPane.showMessageDialog(rootPane, "Debe ingresar un Nombre valido");
        }
    }//GEN-LAST:event_campoUsuarioKeyTyped

    private void campoDniKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoDniKeyTyped
        char valido = evt.getKeyChar();
        if (Character.isLetter(valido)) {
            evt.consume();
            JOptionPane.showMessageDialog(rootPane, "Debe ingresar un DNI valido");
        }
    }//GEN-LAST:event_campoDniKeyTyped

    private void campoContraseñaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_campoContraseñaFocusGained
        campoContraseña.selectAll();
    }//GEN-LAST:event_campoContraseñaFocusGained

    private void tablaUsuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaUsuariosMouseClicked
        botonAgregar.setEnabled(false);
        botonGuardar.setEnabled(false);
        botonEliminar.setEnabled(true);
        botonModificar.setEnabled(true);
        Usuario user = new Usuario();
        UsuarioDAO userDAO = new UsuarioDAO();
        int idu = Integer.parseInt(tablaUsuarios.getValueAt(tablaUsuarios.getSelectedRow(), 0).toString());
        user = userDAO.getUsuarioxID(idu);
        campoUsuario.setText(user.getNombre());
        campoDni.setText(String.valueOf(user.getDNI()));
        campoUsuario.setEnabled(false);
        campoDni.setEnabled(false);
    }//GEN-LAST:event_tablaUsuariosMouseClicked

    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
        Usuario user = new Usuario();
        UsuarioDAO userDAO = new UsuarioDAO();
        int idu = Integer.parseInt(tablaUsuarios.getValueAt(tablaUsuarios.getSelectedRow(), 0).toString());
        if (userDAO.deleteUsuario(idu)) {
            JOptionPane.showMessageDialog(rootPane, "Usuario Eliminado Correctamente");
            mostrarUsuarios();
        } else {
            JOptionPane.showMessageDialog(rootPane, "Hubo un error al intentar Eliminar el Usuario");
        }
    }//GEN-LAST:event_botonEliminarActionPerformed

    private void botonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonModificarActionPerformed
        campoUsuario.setEnabled(true);
        campoDni.setEnabled(true);
        botonModificar.setEnabled(false);
        botonEliminar.setEnabled(false);
        botonGuardar.setEnabled(true);
        modificar = true;
    }//GEN-LAST:event_botonModificarActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonEliminar;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JButton botonModificar;
    private javax.swing.JButton botonSalir;
    private javax.swing.JPasswordField campoContraseña;
    private javax.swing.JTextField campoDni;
    private javax.swing.JTextField campoUsuario;
    private javax.swing.JLabel etiquetaContraseña;
    private javax.swing.JLabel etiquetaDNI;
    private javax.swing.JLabel etiquetaUsuario;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaUsuarios;
    // End of variables declaration//GEN-END:variables
}
