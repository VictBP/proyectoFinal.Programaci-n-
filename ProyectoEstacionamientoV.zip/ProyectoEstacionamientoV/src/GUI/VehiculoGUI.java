package GUI;

import DAO.ColorDAO;
import DAO.MarcaDAO;
import DAO.ModeloDAO;
import DAO.TipoDAO;
import DAO.VehiculoDAO;
import Entidades.Cochera;
import Entidades.Color;
import Entidades.Marca;
import Entidades.Modelo;
import Entidades.Tipo;
import Entidades.Vehiculo;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.util.LinkedList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class VehiculoGUI extends javax.swing.JDialog {

    int idvehiculo;
    VehiculoDAO vehiculodao = new VehiculoDAO();
    Vehiculo vehiculo = new Vehiculo();

    private boolean modificar = false;

    public VehiculoGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        mostrarVehiculos();
        inicializarComponentes(false);
        botonGuardar.setEnabled(false);
        botonEliminar.setEnabled(false);
        botonModificar.setEnabled(false);
    }

    void inicializarComponentes(boolean b) {
        campoPatente.setEnabled(b);
        TextPrompt prompTxtPatente = new TextPrompt("Ingrese la Patente", campoPatente);
        prompTxtPatente.setForeground(java.awt.Color.LIGHT_GRAY);
        prompTxtPatente.changeAlpha(0.7f);
        prompTxtPatente.changeStyle(Font.LAYOUT_LEFT_TO_RIGHT + Font.ROMAN_BASELINE + Font.ITALIC);
        initCmbColor();
      
        comboBoxColor.setEnabled(b);
        comboBoxAnio.setEnabled(b);
        initCmbTipo();
        comboBoxTipo.setEnabled(b);
        initCmbMarcas();
        comboBoxMarca.setEnabled(b);
        initCmbModelos();
        comboBoxModelo.setEnabled(b);
        comboBoxAnio.setSelectedItem(2020);
    }

    private void actualizarCombo(JComboBox combo, String descripcion, Class clase) {
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (combo.getItemAt(i).toString().equals(descripcion)) {
                combo.setSelectedIndex(i);
                return;
            }
        }
    }

    private void initCmbTipo() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        TipoDAO tipoDao = new TipoDAO();
        LinkedList<Tipo> lista = tipoDao.getAllTipos();
        
        lista.forEach((tipo) -> {
            modelo.addElement(tipo.getDescripcion());
        });
        comboBoxTipo.setModel(modelo);
    }

    void actualizarModelo(int idmarca) {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        ModeloDAO modelodao = new ModeloDAO();
        LinkedList<Modelo> lista = modelodao.getAllModelosxMarca(idmarca);
        
        lista.forEach((model) -> {
            modelo.addElement(model.getDescripcion());
        });
        comboBoxModelo.setModel(modelo);
    }

    void initCmbMarcas() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        MarcaDAO marcadao = new MarcaDAO();
        LinkedList<Marca> listaMarcas = marcadao.getAllMarcas();  
        listaMarcas.forEach((marca) -> {
           modelo.addElement(marca.getDescripcion());
        });
        comboBoxMarca.setModel(modelo);
    }

    void initCmbModelos() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        ModeloDAO modelodao = new ModeloDAO();
        LinkedList<Modelo> lista = modelodao.getAllModelosCmb();
        lista.forEach((model) -> {
            modelo.addElement(model.getDescripcion());
        });
        comboBoxModelo.setModel(modelo);
    }

    void initCmbColor() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        ColorDAO colorDAO = new ColorDAO();
        LinkedList<Color> lista = colorDAO.getAllColores();
        lista.forEach((colo) -> {
            modelo.addElement(colo.getDescripcion());
        });
        comboBoxColor.setModel(modelo);
    }

    private void mostrarVehiculos() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Id del Dominio");
        modelo.addColumn("Patente");
        modelo.addColumn("Tipo");
        modelo.addColumn("Color");
        modelo.addColumn("Año");
        modelo.addColumn("Marca");
        modelo.addColumn("Modelo");

        VehiculoDAO autodao = new VehiculoDAO();
        LinkedList<Vehiculo> lista = new LinkedList<Vehiculo>();
        lista = autodao.getAllVehiculos();

        Object[] datos = new Object[7];
        for (Vehiculo dato : lista) {
            datos[0] = dato.getIddominio();
            datos[1] = dato.getPatente();
            datos[2] = dato.getTipo().getDescripcion();
            datos[3] = dato.getColor().getDescripcion();
            datos[4] = dato.getAnio();
            datos[5] = dato.getMarca().getDescripcion();
            datos[6] = dato.getModelo().getDescripcion();
            modelo.addRow(datos);
        }
        tablaVehiculo.setModel(modelo);
        TableColumn columna1 = tablaVehiculo.getColumnModel().getColumn(0);
        TableColumn columna2 = tablaVehiculo.getColumnModel().getColumn(1);
        TableColumn columna3 = tablaVehiculo.getColumnModel().getColumn(2);
        TableColumn columna4 = tablaVehiculo.getColumnModel().getColumn(3);
        TableColumn columna5 = tablaVehiculo.getColumnModel().getColumn(4);
        TableColumn columna6 = tablaVehiculo.getColumnModel().getColumn(5);
        TableColumn columna7 = tablaVehiculo.getColumnModel().getColumn(6);
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaVehiculo = new javax.swing.JTable();
        botonSalir = new javax.swing.JButton();
        etiquetaPatente = new javax.swing.JLabel();
        etiquetaTipo = new javax.swing.JLabel();
        etiquetaColor = new javax.swing.JLabel();
        etiquetaAño = new javax.swing.JLabel();
        etiquetaMarca = new javax.swing.JLabel();
        etiquetaModelo = new javax.swing.JLabel();
        campoPatente = new javax.swing.JTextField();
        comboBoxAnio = new javax.swing.JComboBox<>();
        comboBoxMarca = new javax.swing.JComboBox<>();
        comboBoxModelo = new javax.swing.JComboBox<>();
        botonEliminar = new javax.swing.JButton();
        comboBoxTipo = new javax.swing.JComboBox<>();
        comboBoxColor = new javax.swing.JComboBox<>();
        botonGuardar = new javax.swing.JButton();
        botonAgregar = new javax.swing.JButton();
        botonModificar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        tablaVehiculo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaVehiculo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaVehiculoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaVehiculo);

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        etiquetaPatente.setText("Patente:");

        etiquetaTipo.setText("Tipo:");

        etiquetaColor.setText("Color:");

        etiquetaAño.setText("Año:");

        etiquetaMarca.setText("Marca:");

        etiquetaModelo.setText("Modelo:");

        comboBoxAnio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        comboBoxMarca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxMarcaActionPerformed(evt);
            }
        });

        comboBoxModelo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        botonEliminar.setText("Eliminar");
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });

        comboBoxTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        comboBoxColor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        botonGuardar.setText("Guardar");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonAgregar.setText("Agregar");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        botonModificar.setText("Modificar");
        botonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonModificarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 656, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(botonModificar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonAgregar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonGuardar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botonEliminar)
                        .addGap(18, 18, 18)
                        .addComponent(botonSalir))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(etiquetaModelo)
                                    .addComponent(etiquetaMarca))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(comboBoxModelo, 0, 151, Short.MAX_VALUE)
                                    .addComponent(comboBoxMarca, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(etiquetaPatente)
                                        .addComponent(etiquetaTipo))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(campoPatente, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                                        .addComponent(comboBoxTipo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(etiquetaColor)
                                        .addComponent(etiquetaAño))
                                    .addGap(18, 18, 18)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(comboBoxAnio, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(comboBoxColor, 0, 191, Short.MAX_VALUE)))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaPatente)
                    .addComponent(campoPatente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaTipo)
                    .addComponent(comboBoxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaColor)
                    .addComponent(comboBoxColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaAño)
                    .addComponent(comboBoxAnio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaMarca)
                    .addComponent(comboBoxMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaModelo)
                    .addComponent(comboBoxModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonSalir)
                    .addComponent(botonEliminar)
                    .addComponent(botonGuardar)
                    .addComponent(botonAgregar)
                    .addComponent(botonModificar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

     private void botonSalirMouseClicked(java.awt.event.MouseEvent evt) {     
     }
     
    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_botonSalirActionPerformed

    private void botonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonModificarActionPerformed
        botonModificar.setEnabled(false);
        botonEliminar.setEnabled(false);
        botonGuardar.setEnabled(true);
        //inicializarComponentes(true);
        comboBoxModelo.setEnabled(true);
        comboBoxMarca.setEnabled(true);
        comboBoxColor.setEnabled(true);
        comboBoxTipo.setEnabled(true);
        comboBoxAnio.setEnabled(true);
        modificar = true; /// ca
    }//GEN-LAST:event_botonModificarActionPerformed

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        botonGuardar.setEnabled(true);
        botonAgregar.setEnabled(false);
        inicializarComponentes(true);
    }//GEN-LAST:event_botonAgregarActionPerformed

    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        Cochera cochera = new Cochera();
        VehiculoDAO autodao = new VehiculoDAO();
        Vehiculo auto = new Vehiculo();
        auto.setPatente(campoPatente.getText());
        auto.setTipo((Tipo) (comboBoxTipo.getSelectedItem()));
        auto.setColor((Entidades.Color) (comboBoxColor.getSelectedItem()));
        auto.setAnio((int) comboBoxAnio.getSelectedItem());
        auto.setMarca((Marca) comboBoxMarca.getSelectedItem());
        auto.setModelo((Modelo) comboBoxModelo.getSelectedItem());
        
        if (modificar) {
            auto.setIddominio(Integer.parseInt(tablaVehiculo.getValueAt(tablaVehiculo.getSelectedRow(), 0).toString()));
            if (autodao.modificarVehiculo(auto)) {
                JOptionPane.showMessageDialog(rootPane, "El Vehiculo fue Modificado con exito");
                mostrarVehiculos();

                botonGuardar.setEnabled(false);
                botonAgregar.setEnabled(true);
                inicializarComponentes(false);
                modificar = false;   
            } else {
                System.out.println("fallo algo al Modificar el Vehiculo");
            }
        } else {
            if (autodao.agregarVehiculo(auto,cochera)) {
                mostrarVehiculos();
                JOptionPane.showMessageDialog(rootPane, "El VEHICULO fue Ingresado con exito");
                inicializarComponentes(false);
                botonGuardar.setEnabled(false);
                botonAgregar.setEnabled(true);
            } else {
                System.out.println("fallo el insert de Vehiculo en GUI");
            }
        }
    }//GEN-LAST:event_botonGuardarActionPerformed

    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
        Vehiculo auto = new Vehiculo();
        VehiculoDAO autoDAO = new VehiculoDAO();
        int idauto = Integer.parseInt(tablaVehiculo.getValueAt(tablaVehiculo.getSelectedRow(), 0).toString());
       
        if (JOptionPane.showConfirmDialog(this, "Esta seguro de Eliminar el Vehiculo??") != 0) {
            return;
        }
        if (autoDAO.deleteVehiculo(idauto)) {
            JOptionPane.showMessageDialog(rootPane, "Vehiculo Eliminado Correctamente");
            mostrarVehiculos();
        } else {
            JOptionPane.showMessageDialog(rootPane, "Hubo un error al intentar Eliminar el Usuario");
        }
    }//GEN-LAST:event_botonEliminarActionPerformed

    private void tablaVehiculoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaVehiculoMouseClicked
        // TODO add your handling code here:
        botonGuardar.setEnabled(true);
        botonEliminar.setEnabled(true);
        botonModificar.setEnabled(true);
        Vehiculo auto = new Vehiculo();
        VehiculoDAO autoDAO = new VehiculoDAO();
        int idauto = Integer.parseInt(tablaVehiculo.getValueAt(tablaVehiculo.getSelectedRow(), 0).toString());
        //System.out.println(idauto);
        auto = autoDAO.getvehiculoxID(idauto);
        //System.out.println(auto);   
      
        campoPatente.setText(auto.getPatente());
        System.out.println(auto.getTipo().getDescripcion());
        actualizarCombo(comboBoxTipo, auto.getTipo().getDescripcion().toString(), Tipo.class);
        actualizarCombo(comboBoxColor, auto.getColor().getDescripcion().toString(), Color.class);
        comboBoxAnio.setSelectedItem(auto.getAnio());
        actualizarCombo(comboBoxMarca, auto.getMarca().getDescripcion().toString(), Marca.class);
        actualizarCombo(comboBoxModelo, auto.getModelo().getDescripcion().toString(), Modelo.class);
    }//GEN-LAST:event_tablaVehiculoMouseClicked

    private void comboBoxMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxMarcaActionPerformed
        Marca marca = new Marca();
        marca = (Marca) comboBoxMarca.getSelectedItem();
        int idmod = marca.getIdmarca();
        actualizarModelo(idmod);
    }//GEN-LAST:event_comboBoxMarcaActionPerformed

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonEliminar;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JButton botonModificar;
    private javax.swing.JButton botonSalir;
    private javax.swing.JTextField campoPatente;
    private javax.swing.JComboBox<String> comboBoxAnio;
    private javax.swing.JComboBox<String> comboBoxColor;
    private javax.swing.JComboBox<String> comboBoxMarca;
    private javax.swing.JComboBox<String> comboBoxModelo;
    private javax.swing.JComboBox<String> comboBoxTipo;
    private javax.swing.JLabel etiquetaAño;
    private javax.swing.JLabel etiquetaColor;
    private javax.swing.JLabel etiquetaMarca;
    private javax.swing.JLabel etiquetaModelo;
    private javax.swing.JLabel etiquetaPatente;
    private javax.swing.JLabel etiquetaTipo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaVehiculo;
    // End of variables declaration//GEN-END:variables
}
