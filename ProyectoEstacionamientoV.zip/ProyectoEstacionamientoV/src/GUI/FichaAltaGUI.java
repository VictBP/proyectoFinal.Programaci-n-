
package GUI;

import GUI.ClienteGUI;
import DAO.ClienteDAO;
import DAO.CocheraDAO;
import DAO.ColorDAO;
import DAO.DireccionDAO;
import DAO.LocalidadDAO;
import DAO.MarcaDAO;
import DAO.ModeloDAO;
import DAO.ProvinciaDAO;
import DAO.TipoDAO;
import DAO.UsuarioDAO;
import DAO.VehiculoDAO;
import Entidades.Cliente;
import Entidades.Cochera;
import Entidades.Color;
import Entidades.Direccion;
import Entidades.Localidad;
import Entidades.Marca;
import Entidades.Modelo;
import Entidades.Provincia;
import Entidades.Tipo;
import Entidades.Vehiculo;
import Entidades.Vehiculocc;
import java.awt.Font;
import java.util.Date;
import java.util.LinkedList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;


public class FichaAltaGUI extends javax.swing.JDialog {

    private int maxidper;
    private int iddire;
    
    public FichaAltaGUI(JDialog parent, boolean modal) {
        super(parent, modal);
        initComponents();
        ClienteDAO clidao = new ClienteDAO();
        maxidper = clidao.getMaxIDPersona();
        initComboBoxProvincias();
        initComboBoxLocalidades();
        inicializar_componentes(false);
        initComboBoxCocheras(); 
        mostrarVehiculos();
        botonSiguienteDireccion.setEnabled(false);
        botonGuardarVehiculos.setEnabled(false);
        
    }
    
    private void actualizarLocalidad() {
        comboBoxLocalidad.setEnabled(false);
        Provincia prov = (Provincia) comboBoxProvincia.getSelectedItem();
        LocalidadDAO dptoDao = new LocalidadDAO();
        LinkedList<Localidad> lista = dptoDao.getAllLocalidadesxIDProvincia((prov.getIdprovincia()));
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        lista.forEach((departamento) -> {
            modelo.addElement(departamento);
        });
        comboBoxLocalidad.setModel(modelo);
        comboBoxLocalidad.setEnabled(true);
    }
    void initComboBoxProvincias() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        ProvinciaDAO provDao = new ProvinciaDAO();
        LinkedList<Provincia> lista = provDao.getAllProvincias();

        for (Provincia provincia : lista) {
            modelo.addElement(provincia);
        }
        comboBoxProvincia.setModel(modelo);
    }

    void initComboBoxLocalidades() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        comboBoxLocalidad.setModel(modelo);
        comboBoxLocalidad.setEnabled(false);
    }

        void initComboBoxCocheras() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        CocheraDAO cocheraDAO = new CocheraDAO();
        LinkedList<Cochera> lista = cocheraDAO.getAllCocheras();

        for (Cochera cochera : lista) {
            modelo.addElement(cochera);
        }
        comboBoxCochera.setModel(modelo);
    }
    
    void inicializar_componentes(boolean b) {
        campoPatente.setEnabled(b);
        TextPrompt prompTxtPatente = new TextPrompt("Ingrese la Patente", campoPatente);
        prompTxtPatente.setForeground(java.awt.Color.LIGHT_GRAY);
        prompTxtPatente.changeAlpha(0.7f);
        prompTxtPatente.changeStyle(Font.LAYOUT_LEFT_TO_RIGHT + Font.ROMAN_BASELINE + Font.ITALIC);
        initCmbColor();

        comboBoxColor.setEnabled(b);
        campoFecha.setEnabled(b);
        initCmbTipo();
        comboBoxTipo.setEnabled(b);
        initCmbMarcas();
        comboBoxMarca.setEnabled(b);
        initCmbModelos();
        comboBoxModelo.setEnabled(b);
        initComboBoxCocheras();
        comboBoxCochera.setEnabled(b);
    }

    private void actualizarCombo(JComboBox combo, String descripcion, Class clase) {
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (clase.cast(combo.getItemAt(i)).toString().equals(descripcion)) {
                combo.setSelectedIndex(i);
                return;
            }
        }
    }

    private void initCmbTipo() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        TipoDAO tipoDao = new TipoDAO();
        LinkedList<Tipo> lista = tipoDao.getAllTipos();

        lista.forEach((tipo) -> {
            modelo.addElement(tipo);
        });
        comboBoxTipo.setModel(modelo);
    }

    void actualizarModelo(int idmarca) {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        ModeloDAO modelodao = new ModeloDAO();
        LinkedList<Modelo> lista = modelodao.getAllModelosxMarca(idmarca);

        lista.forEach((model) -> {
            modelo.addElement(model);
        });
        comboBoxModelo.setModel(modelo);
    }

    void initCmbMarcas() {
        MarcaDAO marcadao = new MarcaDAO();
        LinkedList<Marca> lista = marcadao.getAllMarcas();
        lista.forEach((marca) -> {
            comboBoxMarca.addItem(marca.toString());
        });
    }

    void initCmbModelos() {
        ModeloDAO modelodao = new ModeloDAO();
        LinkedList<Modelo> lista = modelodao.getAllModelosCmb();
        lista.forEach((modelos) -> {
            comboBoxModelo.addItem(modelos.toString());
        });
    }

    void initCmbColor() {
        ColorDAO colorDAO = new ColorDAO();
        LinkedList<Color> lista = colorDAO.getAllColores();
        lista.forEach((color) -> {
            comboBoxColor.addItem(color.toString());
        });
    }

    private void mostrarVehiculos() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Id del Dominio");
        modelo.addColumn("Patente");
        modelo.addColumn("Tipo");
        modelo.addColumn("Color");
        modelo.addColumn("Año");
        modelo.addColumn("Marca");
        modelo.addColumn("Modelo");
        modelo.addColumn("Cochera");
        

        VehiculoDAO autodao = new VehiculoDAO();
        LinkedList<Vehiculocc> lista = new LinkedList<>();
        lista = autodao.getAllVehiculosxIDpersona(maxidper+1);

        Object[] datos = new Object[8];
        for (Vehiculocc dato : lista) {
            datos[0] = dato.getIddominio();
            datos[1] = dato.getPatente();
            datos[2] = dato.getTipo().getDescripcion();
            datos[3] = dato.getColor().getDescripcion();
            datos[4] = dato.getAnio();
            datos[5] = dato.getMarca().getDescripcion();
            datos[6] = dato.getModelo().getDescripcion();
            datos[7] = dato.getCochera();
            modelo.addRow(datos);
        }
        tablaVehiculo.setModel(modelo);
        TableColumn columna1 = tablaVehiculo.getColumnModel().getColumn(0);
        TableColumn columna2 = tablaVehiculo.getColumnModel().getColumn(1);
        TableColumn columna3 = tablaVehiculo.getColumnModel().getColumn(2);
        TableColumn columna4 = tablaVehiculo.getColumnModel().getColumn(3);
        TableColumn columna5 = tablaVehiculo.getColumnModel().getColumn(4);
        TableColumn columna6 = tablaVehiculo.getColumnModel().getColumn(5);
        TableColumn columna7 = tablaVehiculo.getColumnModel().getColumn(6);
        TableColumn columna8 = tablaVehiculo.getColumnModel().getColumn(7);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        panelPrincipal = new javax.swing.JPanel();
        etiquetaCuil = new javax.swing.JLabel();
        etiquetaNombre = new javax.swing.JLabel();
        etiquetaApellido = new javax.swing.JLabel();
        etiquetaFecha = new javax.swing.JLabel();
        etiquetaEmail = new javax.swing.JLabel();
        etiquetaTelefono1 = new javax.swing.JLabel();
        etiquetaTelefono2 = new javax.swing.JLabel();
        etiquetaTelefono3 = new javax.swing.JLabel();
        campoCuil = new javax.swing.JTextField();
        campoNombre = new javax.swing.JTextField();
        campoApellido = new javax.swing.JTextField();
        campoTelefono1 = new javax.swing.JTextField();
        campoEmail = new javax.swing.JTextField();
        campoTelefono2 = new javax.swing.JTextField();
        campoTelefono3 = new javax.swing.JTextField();
        campoFecha = new com.toedter.calendar.JDateChooser();
        botonSalir = new javax.swing.JButton();
        botonSiguiente = new javax.swing.JButton();
        botonGuardar = new javax.swing.JButton();
        panelDireccion = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Localidad = new javax.swing.JLabel();
        campoCalle = new javax.swing.JTextField();
        campoNumero = new javax.swing.JTextField();
        campoDepartamento = new javax.swing.JTextField();
        campoPiso = new javax.swing.JTextField();
        campoCP = new javax.swing.JTextField();
        comboBoxProvincia = new javax.swing.JComboBox<>();
        comboBoxLocalidad = new javax.swing.JComboBox<>();
        botonSalirDireccion = new javax.swing.JButton();
        botonSiguienteDireccion = new javax.swing.JButton();
        botonGuardarDireccion = new javax.swing.JButton();
        botonGuardarClienteDireccion = new javax.swing.JButton();
        panelDatos = new javax.swing.JPanel();
        tablaDatos = new javax.swing.JScrollPane();
        tablaVehiculo = new javax.swing.JTable();
        etiquetaPatente = new javax.swing.JLabel();
        etiquetaColor = new javax.swing.JLabel();
        etiquetaAño = new javax.swing.JLabel();
        etiquetaTipo = new javax.swing.JLabel();
        etiqeutaModelo = new javax.swing.JLabel();
        etiquetaMarca = new javax.swing.JLabel();
        etiquetaCochera = new javax.swing.JLabel();
        campoPatente = new javax.swing.JTextField();
        comboBoxColor = new javax.swing.JComboBox<>();
        comboBoxModelo = new javax.swing.JComboBox<>();
        comboBoxTipo = new javax.swing.JComboBox<>();
        comboBoxMarca = new javax.swing.JComboBox<>();
        comboBoxCochera = new javax.swing.JComboBox<>();
        botonSalirDatos = new javax.swing.JButton();
        botonGuardarVehiculos = new javax.swing.JButton();
        botonGuardarClienteDatos = new javax.swing.JButton();
        botonAgregarDatos = new javax.swing.JButton();
        chooserAnio = new com.toedter.calendar.JYearChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        etiquetaCuil.setText("C.U.I.L:");

        etiquetaNombre.setText("Nombre:");

        etiquetaApellido.setText("Apellido:");

        etiquetaFecha.setText("Fecha de Nacimiento:");

        etiquetaEmail.setText("E-mail:");

        etiquetaTelefono1.setText("Telefono1:");

        etiquetaTelefono2.setText("Telefono2:");

        etiquetaTelefono3.setText("Telefono3:");

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        botonSiguiente.setText("Siguiente");
        botonSiguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSiguienteActionPerformed(evt);
            }
        });

        botonGuardar.setText("Guardar Cliente");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelPrincipalLayout = new javax.swing.GroupLayout(panelPrincipal);
        panelPrincipal.setLayout(panelPrincipalLayout);
        panelPrincipalLayout.setHorizontalGroup(
            panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPrincipalLayout.createSequentialGroup()
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelPrincipalLayout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelPrincipalLayout.createSequentialGroup()
                                .addComponent(etiquetaApellido)
                                .addGap(18, 18, 18)
                                .addComponent(campoApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelPrincipalLayout.createSequentialGroup()
                                .addComponent(etiquetaNombre)
                                .addGap(18, 18, 18)
                                .addComponent(campoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelPrincipalLayout.createSequentialGroup()
                                .addComponent(etiquetaCuil)
                                .addGap(18, 18, 18)
                                .addComponent(campoCuil, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelPrincipalLayout.createSequentialGroup()
                                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(etiquetaTelefono1)
                                    .addComponent(etiquetaEmail))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(campoEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(campoTelefono1, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(panelPrincipalLayout.createSequentialGroup()
                                    .addComponent(etiquetaTelefono3)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(campoTelefono3))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelPrincipalLayout.createSequentialGroup()
                                    .addComponent(etiquetaTelefono2)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(campoTelefono2, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(panelPrincipalLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(etiquetaFecha)
                        .addGap(18, 18, 18)
                        .addComponent(campoFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(133, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelPrincipalLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelPrincipalLayout.createSequentialGroup()
                        .addComponent(botonGuardar)
                        .addGap(18, 18, 18)
                        .addComponent(botonSiguiente))
                    .addComponent(botonSalir))
                .addGap(18, 18, 18))
        );
        panelPrincipalLayout.setVerticalGroup(
            panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPrincipalLayout.createSequentialGroup()
                .addGap(117, 117, 117)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaCuil)
                    .addComponent(campoCuil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaNombre)
                    .addComponent(campoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaApellido)
                    .addComponent(campoApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(etiquetaFecha)
                    .addComponent(campoFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaEmail)
                    .addComponent(campoEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaTelefono1)
                    .addComponent(campoTelefono1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaTelefono2, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoTelefono2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaTelefono3)
                    .addComponent(campoTelefono3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonSiguiente)
                    .addComponent(botonGuardar))
                .addGap(18, 18, 18)
                .addComponent(botonSalir)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Principal", panelPrincipal);

        jLabel1.setText("Calle:");

        jLabel2.setText("Numero:");

        jLabel3.setText("Departamento:");

        jLabel4.setText("Piso:");

        jLabel5.setText("Codigo Postal:");

        jLabel6.setText("Provincia:");

        Localidad.setText("Localidad:");

        comboBoxProvincia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxProvincia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxProvinciaActionPerformed(evt);
            }
        });

        comboBoxLocalidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxLocalidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxLocalidadActionPerformed(evt);
            }
        });

        botonSalirDireccion.setText("Salir");
        botonSalirDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirDireccionActionPerformed(evt);
            }
        });

        botonSiguienteDireccion.setText("Siguiente");
        botonSiguienteDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSiguienteDireccionActionPerformed(evt);
            }
        });

        botonGuardarDireccion.setText("Guardar Direccion");
        botonGuardarDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarDireccionActionPerformed(evt);
            }
        });

        botonGuardarClienteDireccion.setText("Guardar Cliente");
        botonGuardarClienteDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarClienteDireccionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelDireccionLayout = new javax.swing.GroupLayout(panelDireccion);
        panelDireccion.setLayout(panelDireccionLayout);
        panelDireccionLayout.setHorizontalGroup(
            panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDireccionLayout.createSequentialGroup()
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelDireccionLayout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addGroup(panelDireccionLayout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(campoCalle, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelDireccionLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)
                            .addComponent(Localidad))
                        .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelDireccionLayout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(comboBoxLocalidad, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(comboBoxProvincia, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(panelDireccionLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(campoCP, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(panelDireccionLayout.createSequentialGroup()
                            .addGap(35, 35, 35)
                            .addComponent(jLabel2)
                            .addGap(18, 18, 18)
                            .addComponent(campoNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelDireccionLayout.createSequentialGroup()
                            .addGap(17, 17, 17)
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(campoPiso, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                                .addComponent(campoDepartamento)))))
                .addGap(0, 141, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDireccionLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonSalirDireccion, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDireccionLayout.createSequentialGroup()
                        .addComponent(botonGuardarClienteDireccion)
                        .addGap(18, 18, 18)
                        .addComponent(botonGuardarDireccion)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonSiguienteDireccion)))
                .addContainerGap())
        );
        panelDireccionLayout.setVerticalGroup(
            panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDireccionLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(campoCalle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(59, 59, 59)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(campoNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoDepartamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(campoPiso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoCP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(comboBoxProvincia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBoxLocalidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Localidad))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonSiguienteDireccion)
                    .addComponent(botonGuardarDireccion)
                    .addComponent(botonGuardarClienteDireccion))
                .addGap(18, 18, 18)
                .addComponent(botonSalirDireccion))
        );

        jTabbedPane1.addTab("Direccion", panelDireccion);

        tablaVehiculo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaVehiculo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaVehiculoMouseClicked(evt);
            }
        });
        tablaDatos.setViewportView(tablaVehiculo);

        etiquetaPatente.setText("Patente:");

        etiquetaColor.setText("Color:");

        etiquetaAño.setText("Año:");

        etiquetaTipo.setText("Tipo:");

        etiqeutaModelo.setText("Modelo:");

        etiquetaMarca.setText("Marca:");

        etiquetaCochera.setText("Cochera:");

        comboBoxColor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxColor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxColorActionPerformed(evt);
            }
        });

        comboBoxModelo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxModelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxModeloActionPerformed(evt);
            }
        });

        comboBoxTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxTipoActionPerformed(evt);
            }
        });

        comboBoxMarca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxMarcaActionPerformed(evt);
            }
        });

        comboBoxCochera.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxCochera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxCocheraActionPerformed(evt);
            }
        });

        botonSalirDatos.setText("Salir");
        botonSalirDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirDatosActionPerformed(evt);
            }
        });

        botonGuardarVehiculos.setText("Guardar Vehiculo");
        botonGuardarVehiculos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarVehiculosActionPerformed(evt);
            }
        });

        botonGuardarClienteDatos.setText("Guardar Cliente");
        botonGuardarClienteDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarClienteDatosActionPerformed(evt);
            }
        });

        botonAgregarDatos.setText("Agregar Vehiculo");
        botonAgregarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarDatosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelDatosLayout = new javax.swing.GroupLayout(panelDatos);
        panelDatos.setLayout(panelDatosLayout);
        panelDatosLayout.setHorizontalGroup(
            panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tablaDatos, javax.swing.GroupLayout.DEFAULT_SIZE, 509, Short.MAX_VALUE)
            .addGroup(panelDatosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelDatosLayout.createSequentialGroup()
                            .addComponent(etiquetaCochera)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(comboBoxCochera, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelDatosLayout.createSequentialGroup()
                            .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(etiqeutaModelo)
                                .addComponent(etiquetaMarca))
                            .addGap(18, 18, 18)
                            .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(comboBoxModelo, 0, 117, Short.MAX_VALUE)
                                .addComponent(comboBoxMarca, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(panelDatosLayout.createSequentialGroup()
                        .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(etiquetaPatente)
                            .addComponent(etiquetaColor)
                            .addComponent(etiquetaAño))
                        .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelDatosLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(comboBoxColor, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(campoPatente, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(panelDatosLayout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(chooserAnio, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(panelDatosLayout.createSequentialGroup()
                        .addComponent(etiquetaTipo)
                        .addGap(32, 32, 32)
                        .addComponent(comboBoxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonSalirDatos, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(botonGuardarVehiculos, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(botonGuardarClienteDatos, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(botonAgregarDatos, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        panelDatosLayout.setVerticalGroup(
            panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDatosLayout.createSequentialGroup()
                .addComponent(tablaDatos, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelDatosLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(etiquetaPatente)
                            .addComponent(campoPatente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(etiquetaColor)
                            .addComponent(comboBoxColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(etiquetaAño)
                            .addComponent(chooserAnio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(etiquetaTipo)
                            .addComponent(comboBoxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(etiqeutaModelo)
                            .addComponent(comboBoxModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(etiquetaMarca)
                            .addComponent(comboBoxMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(etiquetaCochera)
                            .addComponent(comboBoxCochera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(16, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDatosLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonAgregarDatos)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botonGuardarClienteDatos)
                        .addGap(18, 18, 18)
                        .addComponent(botonGuardarVehiculos)
                        .addGap(7, 7, 7)
                        .addComponent(botonSalirDatos)
                        .addContainerGap())))
        );

        jTabbedPane1.addTab("Datos del Vehiculo", panelDatos);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonGuardarActionPerformed

    private void botonSiguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSiguienteActionPerformed
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_botonSiguienteActionPerformed

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
        dispose();
    }//GEN-LAST:event_botonSalirActionPerformed

    private void botonGuardarClienteDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarClienteDireccionActionPerformed
        Cliente cliente = new Cliente();
        DireccionDAO diredao = new DireccionDAO();
        ClienteDAO cliDAO = new ClienteDAO();
        Cochera cochera = (Cochera)comboBoxCochera.getSelectedItem();    
    
        cliente.setIdpersona(0);
        cliente.setCuil(Integer.parseInt(campoCuil.getText()));
        cliente.setNombre(campoNombre.getText());
        cliente.setApellido(campoApellido.getText());
        cliente.setF_nacim((java.sql.Date) campoFecha.getDate());
        cliente.setEmail(campoEmail.getText());
        cliente.setTelefono1(campoTelefono1.getText());
        cliente.setTelefono2(campoTelefono2.getText());
        cliente.setTelefono3(campoTelefono3.getText());
        cliente.setDireccion((Direccion) diredao.getDireccionxID(iddire));
        cliente.setIddominio(-1);
        cliente.setIdcochera(cochera.getIdcochera());
            
    
    if (cliDAO.agregarCliente(cliente)){
        JOptionPane.showMessageDialog(rootPane, "El Cliente fue ingresado con exito");
        botonGuardarClienteDatos.setEnabled(false);
        dispose();
               
    }else
    {
        JOptionPane.showMessageDialog(rootPane, "El Cliente NO fue ingresado con exito");
    }

    }//GEN-LAST:event_botonGuardarClienteDireccionActionPerformed

    private void botonGuardarDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarDireccionActionPerformed
         Direccion dire = new Direccion();
        DireccionDAO direDAO = new DireccionDAO();
        dire.setIddireccion(0);
        dire.setCalle(campoCalle.getText());
        dire.setNumero(Integer.parseInt(campoNumero.getText()));
        dire.setPiso(Integer.parseInt(campoPiso.getText()));
        dire.setDepartamento(campoDepartamento.getText());
        dire.setCp(campoCP.getText());
        dire.setLocalidad((Localidad) comboBoxLocalidad.getSelectedItem());
        dire.setProvincia((Provincia) comboBoxProvincia.getSelectedItem());
        iddire = direDAO.agregarDireccion(dire);
        
        if (iddire!= -1) {
            JOptionPane.showMessageDialog(rootPane, "La Dirección se ha ingresado con exito");
            botonSiguienteDireccion.setEnabled(true);
            botonGuardarDireccion.setEnabled(false);
        } else {
            System.out.println("Algo falló al ingresr una nueva direccion!!");
            return;
        }
    }//GEN-LAST:event_botonGuardarDireccionActionPerformed

    private void botonSiguienteDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSiguienteDireccionActionPerformed
        jTabbedPane1.setEnabledAt(1, false);
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_botonSiguienteDireccionActionPerformed

    private void botonSalirDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirDireccionActionPerformed
         dispose();
    }//GEN-LAST:event_botonSalirDireccionActionPerformed

    private void botonAgregarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarDatosActionPerformed
        botonAgregarDatos.setEnabled(false);
        botonGuardarVehiculos.setEnabled(true);
        inicializar_componentes(true);
    }//GEN-LAST:event_botonAgregarDatosActionPerformed

    private void botonGuardarClienteDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarClienteDatosActionPerformed
        Cliente cliente = new Cliente();
    DireccionDAO diredao = new DireccionDAO();
    ClienteDAO cliDAO = new ClienteDAO();
    Cochera cochera = (Cochera)comboBoxCochera.getSelectedItem();    
    
    cliente.setIdpersona(0);
    cliente.setCuil(Integer.parseInt(campoCuil.getText()));
    cliente.setNombre(campoNombre.getText());
    cliente.setApellido(campoApellido.getText());
    //cliente.setF_nacim((java.sql.Date) chooserAnio.getDate());
    cliente.setEmail(campoEmail.getText());
    cliente.setTelefono1(campoTelefono1.getText());
    cliente.setTelefono2(campoTelefono2.getText());
    cliente.setTelefono3(campoTelefono3.getText());
    cliente.setDireccion((Direccion) diredao.getDireccionxID(iddire));
    cliente.setIddominio(-1);
    cliente.setIdcochera(cochera.getIdcochera());
            
    
    if (cliDAO.agregarCliente(cliente)){
        JOptionPane.showMessageDialog(rootPane, "El Cliente fue ingresado con exito");
        botonGuardarClienteDatos.setEnabled(false);
        dispose();
               
    }else
    {
        JOptionPane.showMessageDialog(rootPane, "El Cliente NO fue ingresado con exito");
    }
    }//GEN-LAST:event_botonGuardarClienteDatosActionPerformed

    private void botonGuardarVehiculosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarVehiculosActionPerformed
        Cochera cochera = new Cochera();
        cochera = (Cochera)comboBoxCochera.getSelectedItem();
        
        VehiculoDAO autodao = new VehiculoDAO();
        Vehiculo auto = new Vehiculo();
        auto.setPatente(campoPatente.getText());
        auto.setTipo((Tipo) (comboBoxTipo.getSelectedItem()));
        auto.setColor((Entidades.Color) (comboBoxColor.getSelectedItem()));
        auto.setAnio(chooserAnio.getYear());
        auto.setMarca((Marca) comboBoxMarca.getSelectedItem());
        auto.setModelo((Modelo) comboBoxModelo.getSelectedItem());
        auto.setIdpersona(maxidper + 1);

        if (autodao.agregarVehiculo(auto,cochera)) {
            JOptionPane.showMessageDialog(rootPane, "El VEHICULO fue Ingresado con exito");
            inicializar_componentes(false);
            mostrarVehiculos();
            botonAgregarDatos.setEnabled(true);
            botonGuardarVehiculos.setEnabled(false);
        } else {
            System.out.println("fallo el insert de Vehiculo en GUI");
        }
    }//GEN-LAST:event_botonGuardarVehiculosActionPerformed

    private void botonSalirDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirDatosActionPerformed
         dispose();
    }//GEN-LAST:event_botonSalirDatosActionPerformed

    private void tablaVehiculoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaVehiculoMouseClicked
        
        Vehiculo auto = new Vehiculo();
        VehiculoDAO autoDAO = new VehiculoDAO();
        int idauto = Integer.parseInt(tablaVehiculo.getValueAt(tablaVehiculo.getSelectedRow(), 0).toString());
        auto = autoDAO.getvehiculoxID(idauto);

        campoPatente.setText(auto.getPatente());
        actualizarCombo(comboBoxTipo, auto.getTipo().getDescripcion(), Tipo.class);
        actualizarCombo(comboBoxColor, auto.getColor().getDescripcion(), Color.class);
        chooserAnio.setYear(auto.getAnio());
        actualizarCombo(comboBoxMarca, auto.getMarca().getDescripcion(), Marca.class);
        actualizarCombo(comboBoxModelo, auto.getModelo().getDescripcion(), Modelo.class);
    }//GEN-LAST:event_tablaVehiculoMouseClicked

    private void comboBoxProvinciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxProvinciaActionPerformed
        
    }//GEN-LAST:event_comboBoxProvinciaActionPerformed

    private void comboBoxLocalidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxLocalidadActionPerformed
        actualizarLocalidad();
    }//GEN-LAST:event_comboBoxLocalidadActionPerformed

    private void comboBoxColorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxColorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboBoxColorActionPerformed

    private void comboBoxTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxTipoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboBoxTipoActionPerformed

    private void comboBoxModeloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxModeloActionPerformed
        actualizarModelo(iddire);
    }//GEN-LAST:event_comboBoxModeloActionPerformed

    private void comboBoxMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxMarcaActionPerformed
        Marca marca = new Marca();
        marca = (Marca) comboBoxMarca.getSelectedItem();
        int idmod = marca.getIdmarca();
        actualizarModelo(idmod);
    }//GEN-LAST:event_comboBoxMarcaActionPerformed

    private void comboBoxCocheraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxCocheraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboBoxCocheraActionPerformed

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Localidad;
    private javax.swing.JButton botonAgregarDatos;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JButton botonGuardarClienteDatos;
    private javax.swing.JButton botonGuardarClienteDireccion;
    private javax.swing.JButton botonGuardarDireccion;
    private javax.swing.JButton botonGuardarVehiculos;
    private javax.swing.JButton botonSalir;
    private javax.swing.JButton botonSalirDatos;
    private javax.swing.JButton botonSalirDireccion;
    private javax.swing.JButton botonSiguiente;
    private javax.swing.JButton botonSiguienteDireccion;
    private javax.swing.JTextField campoApellido;
    private javax.swing.JTextField campoCP;
    private javax.swing.JTextField campoCalle;
    private javax.swing.JTextField campoCuil;
    private javax.swing.JTextField campoDepartamento;
    private javax.swing.JTextField campoEmail;
    private com.toedter.calendar.JDateChooser campoFecha;
    private javax.swing.JTextField campoNombre;
    private javax.swing.JTextField campoNumero;
    private javax.swing.JTextField campoPatente;
    private javax.swing.JTextField campoPiso;
    private javax.swing.JTextField campoTelefono1;
    private javax.swing.JTextField campoTelefono2;
    private javax.swing.JTextField campoTelefono3;
    private com.toedter.calendar.JYearChooser chooserAnio;
    private javax.swing.JComboBox<String> comboBoxCochera;
    private javax.swing.JComboBox<String> comboBoxColor;
    private javax.swing.JComboBox<String> comboBoxLocalidad;
    private javax.swing.JComboBox<String> comboBoxMarca;
    private javax.swing.JComboBox<String> comboBoxModelo;
    private javax.swing.JComboBox<String> comboBoxProvincia;
    private javax.swing.JComboBox<String> comboBoxTipo;
    private javax.swing.JLabel etiqeutaModelo;
    private javax.swing.JLabel etiquetaApellido;
    private javax.swing.JLabel etiquetaAño;
    private javax.swing.JLabel etiquetaCochera;
    private javax.swing.JLabel etiquetaColor;
    private javax.swing.JLabel etiquetaCuil;
    private javax.swing.JLabel etiquetaEmail;
    private javax.swing.JLabel etiquetaFecha;
    private javax.swing.JLabel etiquetaMarca;
    private javax.swing.JLabel etiquetaNombre;
    private javax.swing.JLabel etiquetaPatente;
    private javax.swing.JLabel etiquetaTelefono1;
    private javax.swing.JLabel etiquetaTelefono2;
    private javax.swing.JLabel etiquetaTelefono3;
    private javax.swing.JLabel etiquetaTipo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel panelDatos;
    private javax.swing.JPanel panelDireccion;
    private javax.swing.JPanel panelPrincipal;
    private javax.swing.JScrollPane tablaDatos;
    private javax.swing.JTable tablaVehiculo;
    // End of variables declaration//GEN-END:variables
}
