package GUI;

import DAO.LocalidadDAO;
import DAO.ProvinciaDAO;
import Entidades.Localidad;
import Entidades.Provincia;
import java.util.LinkedList;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class LocalidadGUI extends javax.swing.JDialog {

    public LocalidadGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        mostrarLocalidades();
    }

    private void mostrarLocalidades() {

        DefaultTableModel Localidad = new DefaultTableModel();
        Localidad.addColumn("Id Localidad");
        Localidad.addColumn("Nombre");
        Localidad.addColumn("Departamento");
        Localidad.addColumn("Provincia");

        LinkedList<Localidad> listaLocalidad = new LinkedList<>();
        LocalidadDAO loca = new LocalidadDAO();
        ProvinciaDAO provincia = new ProvinciaDAO();

        Object[] datos = new Object[5];
        for (Localidad dato : listaLocalidad) {
            datos[0] = dato.getIdlocalidad();
            datos[1] = dato.getNombre();
            datos[2] = dato.getDepartamento();
            datos[3] = dato.getProvincia();
            Localidad.addRow(datos);
        }

        tablaLocalidad.setModel(Localidad);
        TableColumn col = tablaLocalidad.getColumnModel().getColumn(0);
        TableColumn col1 = tablaLocalidad.getColumnModel().getColumn(1);
        TableColumn col2 = tablaLocalidad.getColumnModel().getColumn(2);
        TableColumn col3 = tablaLocalidad.getColumnModel().getColumn(3);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaLocalidad = new javax.swing.JTable();
        botonSalir = new javax.swing.JButton();
        etiquetaCodigo = new javax.swing.JLabel();
        etiquetaDescripcion = new javax.swing.JLabel();
        campoDescripcion = new javax.swing.JTextField();
        campoId = new javax.swing.JTextField();
        campoCodigo = new javax.swing.JTextField();

        setUndecorated(true);

        tablaLocalidad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaLocalidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tablaLocalidadKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tablaLocalidad);

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        etiquetaCodigo.setText("Codigo:");

        etiquetaDescripcion.setText("Descripcion:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 455, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(botonSalir))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(etiquetaCodigo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(campoId, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(campoCodigo))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(etiquetaDescripcion)
                        .addGap(18, 18, 18)
                        .addComponent(campoDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaCodigo)
                    .addComponent(campoId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaDescripcion)
                    .addComponent(campoDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addComponent(botonSalir)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
        dispose();
    }//GEN-LAST:event_botonSalirActionPerformed

    private void tablaLocalidadKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tablaLocalidadKeyPressed
          Localidad loca = new Localidad();
        LocalidadDAO locaD = new LocalidadDAO();
       
        int idlocalidad = Integer.parseInt(tablaLocalidad.getValueAt(tablaLocalidad.getSelectedRow(), 0).toString());

      
       // loca = locaD.getAllLocalidadesxIDProvincia(idlocalidad);
        campoId.setText(String.valueOf(locaD.getAllLocalidades()));
        //txtDescripcion.setText(locaD.getNombre());
                                             

    }//GEN-LAST:event_tablaLocalidadKeyPressed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonSalir;
    private javax.swing.JTextField campoCodigo;
    private javax.swing.JTextField campoDescripcion;
    private javax.swing.JTextField campoId;
    private javax.swing.JLabel etiquetaCodigo;
    private javax.swing.JLabel etiquetaDescripcion;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaLocalidad;
    // End of variables declaration//GEN-END:variables
}
