package GUI;

import DAO.UsuarioDAO;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import java.awt.event.KeyListener;
import javax.swing.*;

public class LogingGUI extends javax.swing.JFrame {

    public LogingGUI() {
        initComponents();
        this.pack();
        this.campoUsuario.requestFocus();
        this.campoUsuario.selectAll();
        
        TextPrompt prompTxtUsuario = new TextPrompt("  ", campoUsuario);
        prompTxtUsuario.setForeground(Color.BLACK);
        prompTxtUsuario.changeAlpha(0.5f);
        prompTxtUsuario.changeStyle(Font.CENTER_BASELINE + Font.ROMAN_BASELINE + Font.ITALIC);
        campoUsuario.setText("");

        campoContraseña.setText("");
        TextPrompt prompTxtpass = new TextPrompt(" ", campoContraseña);
        prompTxtpass.setForeground(Color.BLACK);
        prompTxtpass.changeAlpha(0.5f);
        prompTxtpass.changeStyle(Font.CENTER_BASELINE + Font.ROMAN_BASELINE + Font.ITALIC);
        campoContraseña.setText("");
        
        this.setDefaultLookAndFeelDecorated(true);
        try {
            UIManager.setLookAndFeel("com.jtattoo.plaf.noire.NoireLookAndFeel");
        } catch (Exception e) {
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Panel = new javax.swing.JPanel();
        etiquetaContraseña = new javax.swing.JLabel();
        botonSalir = new javax.swing.JButton();
        etiquetaUsuario = new javax.swing.JLabel();
        botonInciarSesion = new javax.swing.JButton();
        campoContraseña = new javax.swing.JPasswordField();
        campoUsuario = new javax.swing.JTextField();
        logo = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        etiquetaContraseña.setFont(new java.awt.Font("Baskerville Old Face", 0, 24)); // NOI18N
        etiquetaContraseña.setForeground(new java.awt.Color(255, 255, 255));
        etiquetaContraseña.setText("Contraseña:");
        Panel.add(etiquetaContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 120, 40));

        botonSalir.setBackground(new java.awt.Color(255, 255, 255));
        botonSalir.setFont(new java.awt.Font("Baskerville Old Face", 0, 14)); // NOI18N
        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });
        Panel.add(botonSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 10, 70, -1));

        etiquetaUsuario.setFont(new java.awt.Font("Baskerville Old Face", 0, 24)); // NOI18N
        etiquetaUsuario.setForeground(new java.awt.Color(255, 255, 255));
        etiquetaUsuario.setText("Usuario:");
        Panel.add(etiquetaUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 330, 90, 30));

        botonInciarSesion.setFont(new java.awt.Font("Baskerville Old Face", 0, 14)); // NOI18N
        botonInciarSesion.setText("Iniciar sesion");
        botonInciarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonInciarSesionActionPerformed(evt);
            }
        });
        Panel.add(botonInciarSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 460, -1, -1));

        campoContraseña.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                campoContraseñaKeyPressed(evt);
            }
        });
        Panel.add(campoContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 380, 190, 30));

        campoUsuario.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        campoUsuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                campoUsuarioKeyPressed(evt);
            }
        });
        Panel.add(campoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 330, 190, 30));

        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Free_Sample_By_Wix.jpg"))); // NOI18N
        Panel.add(logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 190, 180));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/images-bicubic.png"))); // NOI18N
        Panel.add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
         this.dispose();
    }//GEN-LAST:event_botonSalirActionPerformed

    private void botonInciarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonInciarSesionActionPerformed
        validarUsuario();
    }//GEN-LAST:event_botonInciarSesionActionPerformed

    private void campoUsuarioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoUsuarioKeyPressed
       if (evt.getModifiers()== KeyEvent.VK_ENTER) {
            this.campoContraseña.requestFocus();
            this.campoContraseña.selectAll();
             
        }
    }//GEN-LAST:event_campoUsuarioKeyPressed

    private void campoContraseñaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoContraseñaKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            validarUsuario();
        }
    }//GEN-LAST:event_campoContraseñaKeyPressed

    private void validarUsuario() {
        String usuario;
        String pwd;

        usuario = this.campoUsuario.getText();
        pwd = this.campoContraseña.getText();
      
        
        UsuarioDAO usrdao = new UsuarioDAO();              
        if (usrdao.validarUsr(Integer.parseInt (usuario),pwd)) {   
            System.out.println("Loggin correcto!!");
            System.out.println(Integer.parseInt(usuario));
            System.out.println(pwd);
            MenuPrincipal menuppal = new MenuPrincipal();  
            this.dispose();                    
            menuppal.setVisible(true); 
            
                       
        } else {
            JOptionPane.showMessageDialog(null, "Usuario o Contraseña NO validos");
            this.campoUsuario.requestFocus();
            this.campoUsuario.selectAll();
        }
    }


    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Panel;
    private javax.swing.JButton botonInciarSesion;
    private javax.swing.JButton botonSalir;
    private javax.swing.JPasswordField campoContraseña;
    private javax.swing.JTextField campoUsuario;
    private javax.swing.JLabel etiquetaContraseña;
    private javax.swing.JLabel etiquetaUsuario;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables
}
   

