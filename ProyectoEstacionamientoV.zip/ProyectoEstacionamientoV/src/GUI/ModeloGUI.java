
package GUI;

import DAO.MarcaDAO;
import DAO.ModeloDAO;
import DAO.TipoDAO;
import Entidades.Marca;
import Entidades.Modelo;
import Entidades.Tipo;
import GUI.TextPrompt;
import GUI.TextPrompt;
import java.awt.Font;
import java.util.LinkedList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class ModeloGUI extends javax.swing.JDialog {
    
    private boolean modificar = false;
    private int idModelo;

    
    public ModeloGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        mostrarModelos();
        inicializarComponentes(false);
        botonGuardar.setEnabled(false);
        botonModificar.setEnabled(false);
        campoModelo.setEnabled(false);
    }

    void inicializarComponentes(boolean b) {
        campoModelo.setEnabled(b);
        TextPrompt prompTxtPatente = new TextPrompt("Ingrese el Modelo", campoModelo);
        prompTxtPatente.setForeground(java.awt.Color.LIGHT_GRAY);
        prompTxtPatente.changeAlpha(0.7f);
        prompTxtPatente.changeStyle(Font.LAYOUT_LEFT_TO_RIGHT + Font.ROMAN_BASELINE + Font.ITALIC);

        comboBoxTipo.setEnabled(b);
        inijCmbTipo();
        comboBoxMarca.setEnabled(b);
        inijCmbMarcas();
    }
    
    private void mostrarModelos() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Id de Modelo");
        modelo.addColumn("Marca");
        modelo.addColumn("Modelo");
        modelo.addColumn("Tipo");

        ModeloDAO Mdldao = new ModeloDAO();
        LinkedList<Modelo> lista = new LinkedList<Modelo>();
        lista = Mdldao.getAllModelos();

        Object[] datos = new Object[4];
        for (Modelo dato : lista) {
            datos[0] = dato.getIdmodelo();
            datos[1] = dato.getMarca().getDescripcion();
            datos[2] = dato.getDescripcion();
            datos[3] = dato.getTipo().getDescripcion();
            modelo.addRow(datos);
        }
        tablaModelos.setModel(modelo);

        TableColumn columna1 = tablaModelos.getColumnModel().getColumn(0);
        TableColumn columna2 = tablaModelos.getColumnModel().getColumn(1);
        TableColumn columna3 = tablaModelos.getColumnModel().getColumn(2);
        TableColumn columna4 = tablaModelos.getColumnModel().getColumn(3);
        
        tablaModelos.setAutoResizeMode(tablaModelos.AUTO_RESIZE_NEXT_COLUMN);
        TableColumnModel columnModel = tablaModelos.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(25);
        columnModel.getColumn(1).setPreferredWidth(300);
        columnModel.getColumn(2).setPreferredWidth(300);
        columnModel.getColumn(3).setPreferredWidth(300);
    }
    
    private void actualizarCombo(JComboBox combo, String descripcion, Class clase) {
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (clase.cast(combo.getItemAt(i)).toString().equals(descripcion)) {
                combo.setSelectedIndex(i);
                return;
            }
        }
    }
    
    private void inijCmbTipo() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        TipoDAO tipoDao = new TipoDAO();
        LinkedList<Tipo> lista = tipoDao.getAllTipos();

        for (Tipo tipo : lista) {
            modelo.addElement(tipo);
        }
        comboBoxTipo.setModel(modelo);
    }
    
     private void cargarDatosModelo(Modelo modelo) {
        inijCmbMarcas();

        if (modelo != null) {
            actualizarCombo(comboBoxTipo, modelo.getTipo().getDescripcion(), Tipo.class);
        } else {
            System.out.println("Algo fallo al cargar el Vehiculo");
        }
    }
     
     void inijCmbMarcas() {
        MarcaDAO marcadao = new MarcaDAO();
        LinkedList<Marca> lista = marcadao.getAllMarcas(); 
        for (Marca marca : lista) {   
            comboBoxMarca.addItem(marca.toString());
        }
      
    }
     
     void actualizarMarca(int idmarca) {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        ModeloDAO modelodao = new ModeloDAO();
        LinkedList<Modelo> lista = modelodao.getAllModelosxMarca(idmarca);
        for (Modelo model : lista) {
            modelo.addElement(model);
        }
    }
     
     private void GuardarModelo(Modelo modelo, boolean modificar) {

        ModeloDAO modelodao = new ModeloDAO();

        if (modificar) {
            System.out.println(modelo.toString());
            if (modelodao.modificarModelo(modelo)) {
                mostrarModelos();
                botonAgregar.setEnabled(false);
            } else {
                System.out.println("Fallo la modificacion de la Marca");
            }
        } else {
            if (modelodao.agregarModelo(modelo)) {
                mostrarModelos();
                botonAgregar.setEnabled(false);
            } else {
                System.out.println("Fallo el ingreso de Marca");
            }
        }
        botonAgregar.setEnabled(true);
        botonGuardar.setEnabled(false);
        campoModelo.setEnabled(false);
        modificar = false;
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaModelos = new javax.swing.JTable();
        botonSalir = new javax.swing.JButton();
        etiquetaMarca = new javax.swing.JLabel();
        etiquetaModelo = new javax.swing.JLabel();
        etiquetaTipo = new javax.swing.JLabel();
        campoModelo = new javax.swing.JTextField();
        comboBoxMarca = new javax.swing.JComboBox<>();
        comboBoxTipo = new javax.swing.JComboBox<>();
        botonGuardar = new javax.swing.JButton();
        botonModificar = new javax.swing.JButton();
        botonAgregar = new javax.swing.JButton();
        botonEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        tablaModelos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaModelos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaModelosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaModelos);

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        etiquetaMarca.setText("Marca:");

        etiquetaModelo.setText("Modelo:");

        etiquetaTipo.setText("Tipo:");

        comboBoxMarca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxMarcaActionPerformed(evt);
            }
        });

        comboBoxTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxTipoActionPerformed(evt);
            }
        });

        botonGuardar.setText("Guardar");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonModificar.setText("Modificar");
        botonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonModificarActionPerformed(evt);
            }
        });

        botonAgregar.setText("Agregar");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        botonEliminar.setText("Eliminar");
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 605, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(etiquetaTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(comboBoxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(etiquetaMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(comboBoxMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(etiquetaModelo)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(campoModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(botonSalir)
                                .addContainerGap())
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(botonEliminar)
                                .addGap(18, 18, 18)
                                .addComponent(botonAgregar)
                                .addGap(18, 18, 18)
                                .addComponent(botonModificar)
                                .addGap(18, 18, 18)
                                .addComponent(botonGuardar)
                                .addGap(52, 52, 52))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(etiquetaMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboBoxMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBoxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(etiquetaTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonGuardar)
                    .addComponent(botonModificar)
                    .addComponent(botonAgregar)
                    .addComponent(botonEliminar))
                .addGap(17, 17, 17)
                .addComponent(botonSalir))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
       dispose();
    }//GEN-LAST:event_botonSalirActionPerformed

    private void comboBoxMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxMarcaActionPerformed
        Marca marca = new Marca();
        marca = (Marca) comboBoxMarca.getSelectedItem();
        int idmod = marca.getIdmarca();
        actualizarMarca(idmod);  
    }//GEN-LAST:event_comboBoxMarcaActionPerformed

    private void comboBoxTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxTipoActionPerformed
        
    }//GEN-LAST:event_comboBoxTipoActionPerformed

    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
       Modelo modelo = new Modelo();
        ModeloDAO modeloDAO = new ModeloDAO();
        int idmodelo = Integer.parseInt(tablaModelos.getValueAt(tablaModelos.getSelectedRow(), 0).toString());

        if (JOptionPane.showConfirmDialog(this, "Esta seguro de Eliminar el modelo??") != 0) {
            return;
        }
        if (modeloDAO.deleteModelo(idmodelo)) {
            //JOptionPane.showMessageDialog(rootPane, "modelo Eliminado Correctamente");
            mostrarModelos();
        } else {
            //JOptionPane.showMessageDialog(rootPane, "Hubo un error al intentar Eliminar el modelo");
        }// TO:
    }//GEN-LAST:event_botonEliminarActionPerformed

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        botonGuardar.setEnabled(true);
        campoModelo.setEnabled(true);
        botonAgregar.setEnabled(false);
        inicializarComponentes(true);
    }//GEN-LAST:event_botonAgregarActionPerformed

    private void botonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonModificarActionPerformed
        botonAgregar.setEnabled(false);
        botonGuardar.setEnabled(true);
        campoModelo.setEnabled(true);
        modificar = true;
        botonModificar.setEnabled(false);
        botonEliminar.setEnabled(false);
        inicializarComponentes(true);
                 
    }//GEN-LAST:event_botonModificarActionPerformed

    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
      
        ModeloDAO modelodao = new ModeloDAO();
        Modelo modelo = new Modelo();
        modelo.setDescripcion(campoModelo.getText());
        modelo.setTipo((Tipo) (comboBoxTipo.getSelectedItem()));
        modelo.setMarca((Marca) comboBoxMarca.getSelectedItem());

        if (modificar) {
            modelo.setIdmodelo(Integer.parseInt(tablaModelos.getValueAt(tablaModelos.getSelectedRow(), 0).toString()));
            if (modelodao.modificarModelo(modelo)) {
               
                mostrarModelos();

                botonGuardar.setEnabled(false);
                botonAgregar.setEnabled(true);
                inicializarComponentes(false);
                modificar = false;   
            } else {
                System.out.println("fallo algo al Modificar el Vehiculo");
            }
        } else {
            if (modelodao.agregarModelo(modelo)) {
                mostrarModelos();
                inicializarComponentes(false);
                botonGuardar.setEnabled(false);
                botonAgregar.setEnabled(true);
            } else {
                System.out.println("fallo el insert de Vehiculo en GUI");
            }
        }
        
    }//GEN-LAST:event_botonGuardarActionPerformed

    private void tablaModelosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaModelosMouseClicked
        botonAgregar.setEnabled(false);
        botonGuardar.setEnabled(false);
        botonEliminar.setEnabled(true);
        botonModificar.setEnabled(true);

        Modelo modelo = new Modelo();
        ModeloDAO tipodao = new ModeloDAO();
        int idtipo = Integer.parseInt(tablaModelos.getValueAt(tablaModelos.getSelectedRow(), 0).toString());
        modelo = tipodao.getModeloxID(idtipo);

        campoModelo.setText(modelo.getDescripcion());
        actualizarCombo(comboBoxTipo, modelo.getTipo().getDescripcion(), Tipo.class);
        actualizarCombo(comboBoxMarca, modelo.getMarca().getDescripcion(), Marca.class);
    }//GEN-LAST:event_tablaModelosMouseClicked

  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonEliminar;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JButton botonModificar;
    private javax.swing.JButton botonSalir;
    private javax.swing.JTextField campoModelo;
    private javax.swing.JComboBox<String> comboBoxMarca;
    private javax.swing.JComboBox<String> comboBoxTipo;
    private javax.swing.JLabel etiquetaMarca;
    private javax.swing.JLabel etiquetaModelo;
    private javax.swing.JLabel etiquetaTipo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaModelos;
    // End of variables declaration//GEN-END:variables
}
