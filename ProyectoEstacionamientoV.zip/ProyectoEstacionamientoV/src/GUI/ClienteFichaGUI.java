
package GUI;

import DAO.ClienteDAO;
import DAO.ColorDAO;
import DAO.DireccionDAO;
import DAO.LocalidadDAO;
import DAO.MarcaDAO;
import DAO.ModeloDAO;
import DAO.ProvinciaDAO;
import DAO.TipoDAO;
import DAO.VehiculoDAO;
import Entidades.Cliente;
import Entidades.Cochera;
import Entidades.Color;
import Entidades.Direccion;
import Entidades.Localidad;
import Entidades.Marca;
import Entidades.Modelo;
import Entidades.Provincia;
import Entidades.Tipo;
import Entidades.Vehiculo;
import Entidades.Vehiculocc;
import java.awt.Font;
import java.sql.Date;
import java.util.LinkedList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class ClienteFichaGUI extends javax.swing.JDialog {
    
    int idCliente = ClienteGUI.idCliente;
    ClienteDAO cliDAO = new ClienteDAO();
    Cliente cliente = cliDAO.getClientexID(idCliente);

    
    public ClienteFichaGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        cargarDatosCliente(cliente);
        initComboBoxProvincias();
        initComboBoxLocalidad();
        mostrarVehiculos();
        inicializarComponentes(false);
    }
    
     private void cargarDatosCliente(Cliente cliente) {

        if (cliente != null) {
            campoCUIL.setText(String.valueOf(cliente.getCuil()));
            campoApellido.setText(cliente.getApellido());
            campoNombre.setText(cliente.getNombre());
            campoFechaNacimiento.setDate(cliente.getF_nacim());
            campoEmail.setText(cliente.getEmail());
            campoTelefono1.setText(cliente.getTelefono1());
            campoTelefono2.setText(cliente.getTelefono2());
            campoCalle.setText(cliente.getDireccion().getCalle());
            campoNumero.setText(String.valueOf((cliente.getDireccion().getNumero())));
            campoDepartamento.setText(cliente.getDireccion().getDepartamento());
            campoPiso.setText(String.valueOf(cliente.getDireccion().getPiso()));
            campoCP.setText(cliente.getDireccion().getCp());
            initComboBoxProvincias();
            initComboBoxLocalidad();         
            actualizarCombo(comboBoxProvincia, cliente.getDireccion().getProvincia().getNombre(), Provincia.class);
            actualizarCombo(comboBoxLocalidad, cliente.getDireccion().getLocalidad().getNombre(), Localidad.class);
            
        } else {
            System.out.println("Algo fallo al cargar el cliente, intentelo nuevamente!");
        }

    }
     
      void inicializarComponentes(boolean b) {
        campoPatente.setEnabled(b);
        TextPrompt prompTxtPatente = new TextPrompt("Ingrese la Patente", campoPatente);
        prompTxtPatente.setForeground(java.awt.Color.LIGHT_GRAY);
        prompTxtPatente.changeAlpha(0.7f);
        prompTxtPatente.changeStyle(Font.LAYOUT_LEFT_TO_RIGHT + Font.ROMAN_BASELINE + Font.ITALIC);
        initComboBoxColor();

        comboBoxColor.setEnabled(b);
        campoFechaNacimiento.setEnabled(b);
        initComboBoxTipo();
        comboBoxTipo.setEnabled(b);
        initComboBoxMarcas();
        comboBoxMarca.setEnabled(b);
        initComboBoxModelos();
        comboBoxModelo.setEnabled(b);
    }
     
     private void actualizarLocalidad(int idp) {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        LocalidadDAO locaDao = new LocalidadDAO();
        LinkedList<Localidad> lista = locaDao.getAllLocalidadesxIDProvincia(idp);

        lista.forEach((localidad) -> {
            modelo.addElement(localidad);
        });
        comboBoxLocalidad.setModel(modelo);
    }
     
     
     private void initComboBoxProvincias() {
        ProvinciaDAO provDao = new ProvinciaDAO();
        LinkedList<Provincia> lista = provDao.getAllProvincias();
        lista.forEach((provincia) -> {
            comboBoxProvincia.addItem(provincia.toString());
        });
    }

    private void initComboBoxLocalidad() {
        LocalidadDAO dptoDao = new LocalidadDAO();
        LinkedList<Localidad> lista = dptoDao.getAllLocalidades();
        lista.forEach((localidad) -> {
            comboBoxLocalidad.addItem(localidad.toString());
        });
    }

    private void actualizarCombo(JComboBox combo, String descripcion, Class clase) {
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (clase.cast(combo.getItemAt(i)).toString().equals(descripcion)) {
                combo.setSelectedIndex(i);
                return;
            }
        }
    }
    
     private void initComboBoxTipo() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        TipoDAO tipoDao = new TipoDAO();
        LinkedList<Tipo> lista = tipoDao.getAllTipos();

        lista.forEach((tipo) -> {
            modelo.addElement(tipo);
        });
        comboBoxTipo.setModel(modelo);
    }
     
     
        void actualizarModelo(int idmarca) {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        ModeloDAO modelodao = new ModeloDAO();
        LinkedList<Modelo> lista = modelodao.getAllModelosxMarca(idmarca);

        lista.forEach((model) -> {
            modelo.addElement(model);
        });
        comboBoxModelo.setModel(modelo);
    }

    void initComboBoxMarcas() {
        MarcaDAO marcadao = new MarcaDAO();
        LinkedList<Marca> lista = marcadao.getAllMarcas();
        lista.forEach((marca) -> {
        comboBoxMarca.addItem(marca.toString());
        });
    }

    void initComboBoxModelos() {
        ModeloDAO modelodao = new ModeloDAO();
        LinkedList<Modelo> lista = modelodao.getAllModelosCmb();
        lista.forEach((modelos) -> {
            comboBoxModelo.addItem(modelos.toString());
        });
    }

    void initComboBoxColor() {
        ColorDAO colorDAO = new ColorDAO();
        LinkedList<Color> lista = colorDAO.getAllColores();
        lista.forEach((color) -> {
            comboBoxColor.addItem(color.toString());
        });
    }

    private void mostrarVehiculos() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Id del Dominio");
        modelo.addColumn("Patente");
        modelo.addColumn("Tipo");
        modelo.addColumn("Color");
        modelo.addColumn("Año");
        modelo.addColumn("Marca");
        modelo.addColumn("Modelo");
        modelo.addColumn("Cochera");

        VehiculoDAO autodao = new VehiculoDAO();
        LinkedList<Vehiculocc> lista = autodao.getAllVehiculosxIDpersona(cliente.getIdpersona());

        Object[] datos = new Object[8];
        for (Vehiculocc dato : lista) {
            datos[0] = dato.getIddominio();
            datos[1] = dato.getPatente();
            datos[2] = dato.getTipo().getDescripcion();
            datos[3] = dato.getColor().getDescripcion();
            datos[4] = dato.getAnio();
            datos[5] = dato.getMarca().getDescripcion();
            datos[6] = dato.getModelo().getDescripcion();
            datos[7] = dato.getCochera();
            
            modelo.addRow(datos);
        }
        tablaVehiculo.setModel(modelo);
        TableColumn columna1 = tablaVehiculo.getColumnModel().getColumn(0);
        TableColumn columna2 = tablaVehiculo.getColumnModel().getColumn(1);
        TableColumn columna3 = tablaVehiculo.getColumnModel().getColumn(2);
        TableColumn columna4 = tablaVehiculo.getColumnModel().getColumn(3);
        TableColumn columna5 = tablaVehiculo.getColumnModel().getColumn(4);
        TableColumn columna6 = tablaVehiculo.getColumnModel().getColumn(5);
        TableColumn columna7 = tablaVehiculo.getColumnModel().getColumn(6);
        TableColumn columna8 = tablaVehiculo.getColumnModel().getColumn(7);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        panelPrincipal = new javax.swing.JPanel();
        etiquetaCUIL = new javax.swing.JLabel();
        etiquetaApellido = new javax.swing.JLabel();
        etiquetaNombre = new javax.swing.JLabel();
        etiquetaNacimiento = new javax.swing.JLabel();
        etiquetaEmail = new javax.swing.JLabel();
        etiquetaTelefono1 = new javax.swing.JLabel();
        etiquetaTelefono2 = new javax.swing.JLabel();
        campoCUIL = new javax.swing.JTextField();
        campoApellido = new javax.swing.JTextField();
        campoNombre = new javax.swing.JTextField();
        campoEmail = new javax.swing.JTextField();
        campoTelefono1 = new javax.swing.JTextField();
        campoTelefono2 = new javax.swing.JTextField();
        campoFechaNacimiento = new com.toedter.calendar.JDateChooser();
        panelDireccion = new javax.swing.JPanel();
        etiquetaCalle = new javax.swing.JLabel();
        etiquetaNuemero = new javax.swing.JLabel();
        etiquetaPiso = new javax.swing.JLabel();
        etiquetaDepartamento = new javax.swing.JLabel();
        etiquetaCP = new javax.swing.JLabel();
        etiquetaProvincia = new javax.swing.JLabel();
        etiquetaLocalidad = new javax.swing.JLabel();
        campoCalle = new javax.swing.JTextField();
        campoNumero = new javax.swing.JTextField();
        campoPiso = new javax.swing.JTextField();
        campoDepartamento = new javax.swing.JTextField();
        campoCP = new javax.swing.JTextField();
        comboBoxProvincia = new javax.swing.JComboBox<>();
        comboBoxLocalidad = new javax.swing.JComboBox<>();
        panelDatosVehiculo = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaVehiculo = new javax.swing.JTable();
        etiquetaPatente = new javax.swing.JLabel();
        etiquetaColor = new javax.swing.JLabel();
        etiquetaAño = new javax.swing.JLabel();
        etiquetaTipo = new javax.swing.JLabel();
        etiquetaMarca = new javax.swing.JLabel();
        etiquetaModelo = new javax.swing.JLabel();
        etiquetaCochera = new javax.swing.JLabel();
        campoPatente = new javax.swing.JTextField();
        comboBoxColor = new javax.swing.JComboBox<>();
        comboBoxTipo = new javax.swing.JComboBox<>();
        comboBoxMarca = new javax.swing.JComboBox<>();
        comboBoxModelo = new javax.swing.JComboBox<>();
        comboBoxCochera = new javax.swing.JComboBox<>();
        chooserAnio = new com.toedter.calendar.JYearChooser();
        botonSalir = new javax.swing.JButton();
        botonActualizar = new javax.swing.JButton();
        botonGuardar = new javax.swing.JButton();
        botonAgregar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        jTabbedPane1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTabbedPane1FocusGained(evt);
            }
        });

        etiquetaCUIL.setText("C.U.I.L:");

        etiquetaApellido.setText("Apellidos:");

        etiquetaNombre.setText("Nombres:");

        etiquetaNacimiento.setText("Fecha de Nacimiento:");

        etiquetaEmail.setText("E-mail:");

        etiquetaTelefono1.setText("Telefono1:");

        etiquetaTelefono2.setText("Telefono2:");

        javax.swing.GroupLayout panelPrincipalLayout = new javax.swing.GroupLayout(panelPrincipal);
        panelPrincipal.setLayout(panelPrincipalLayout);
        panelPrincipalLayout.setHorizontalGroup(
            panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPrincipalLayout.createSequentialGroup()
                .addGap(136, 136, 136)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(etiquetaNombre, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(etiquetaApellido, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(etiquetaNacimiento)
                    .addComponent(etiquetaEmail)
                    .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(etiquetaTelefono2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(etiquetaTelefono1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(etiquetaCUIL))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(campoCUIL)
                    .addComponent(campoApellido)
                    .addComponent(campoNombre)
                    .addComponent(campoEmail)
                    .addComponent(campoTelefono1)
                    .addComponent(campoTelefono2)
                    .addComponent(campoFechaNacimiento, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelPrincipalLayout.setVerticalGroup(
            panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPrincipalLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(etiquetaCUIL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(campoCUIL, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addGap(56, 56, 56)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(etiquetaApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelPrincipalLayout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(campoApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(etiquetaNacimiento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(campoFechaNacimiento, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaTelefono1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoTelefono1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoTelefono2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(etiquetaTelefono2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(154, 154, 154))
        );

        jTabbedPane1.addTab("Principal", panelPrincipal);

        etiquetaCalle.setText("Calle:");

        etiquetaNuemero.setText("Numero:");

        etiquetaPiso.setText("Piso:");

        etiquetaDepartamento.setText("Departamento:");

        etiquetaCP.setText("Codigo Postal:");

        etiquetaProvincia.setText("Provincia:");

        etiquetaLocalidad.setText("Localidad:");

        comboBoxProvincia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxProvincia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxProvinciaActionPerformed(evt);
            }
        });

        comboBoxLocalidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxLocalidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxLocalidadActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelDireccionLayout = new javax.swing.GroupLayout(panelDireccion);
        panelDireccion.setLayout(panelDireccionLayout);
        panelDireccionLayout.setHorizontalGroup(
            panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDireccionLayout.createSequentialGroup()
                .addGap(224, 224, 224)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(etiquetaProvincia)
                    .addComponent(etiquetaLocalidad))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(comboBoxProvincia, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboBoxLocalidad, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(199, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDireccionLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDireccionLayout.createSequentialGroup()
                        .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDireccionLayout.createSequentialGroup()
                                .addComponent(etiquetaCalle)
                                .addGap(18, 18, 18)
                                .addComponent(campoCalle, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDireccionLayout.createSequentialGroup()
                                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(etiquetaPiso)
                                    .addComponent(etiquetaNuemero))
                                .addGap(18, 18, 18)
                                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(campoNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(campoPiso, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(63, 63, 63))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDireccionLayout.createSequentialGroup()
                        .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelDireccionLayout.createSequentialGroup()
                                .addComponent(etiquetaDepartamento)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(panelDireccionLayout.createSequentialGroup()
                                .addComponent(etiquetaCP)
                                .addGap(18, 18, 18)))
                        .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(campoCP, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(campoDepartamento, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55))))
        );
        panelDireccionLayout.setVerticalGroup(
            panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDireccionLayout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaCalle)
                    .addComponent(campoCalle, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaNuemero)
                    .addComponent(campoNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaPiso)
                    .addComponent(campoPiso, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaDepartamento)
                    .addComponent(campoDepartamento, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoCP, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(etiquetaCP, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaProvincia)
                    .addComponent(comboBoxProvincia, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(panelDireccionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaLocalidad)
                    .addComponent(comboBoxLocalidad, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Direccion", panelDireccion);

        tablaVehiculo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaVehiculo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaVehiculoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaVehiculo);

        etiquetaPatente.setText("Patente:");

        etiquetaColor.setText("Color:");

        etiquetaAño.setText("Año:");

        etiquetaTipo.setText("Tipo:");

        etiquetaMarca.setText("Marca:");

        etiquetaModelo.setText("Modelo:");

        etiquetaCochera.setText("Cochera:");

        comboBoxColor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxColor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxColorActionPerformed(evt);
            }
        });

        comboBoxTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxTipoActionPerformed(evt);
            }
        });

        comboBoxMarca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxMarcaActionPerformed(evt);
            }
        });

        comboBoxModelo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxModelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxModeloActionPerformed(evt);
            }
        });

        comboBoxCochera.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboBoxCochera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxCocheraActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelDatosVehiculoLayout = new javax.swing.GroupLayout(panelDatosVehiculo);
        panelDatosVehiculo.setLayout(panelDatosVehiculoLayout);
        panelDatosVehiculoLayout.setHorizontalGroup(
            panelDatosVehiculoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 630, Short.MAX_VALUE)
            .addGroup(panelDatosVehiculoLayout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addGroup(panelDatosVehiculoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(etiquetaCochera)
                    .addComponent(etiquetaModelo)
                    .addComponent(etiquetaMarca)
                    .addComponent(etiquetaTipo)
                    .addComponent(etiquetaAño)
                    .addComponent(etiquetaColor)
                    .addComponent(etiquetaPatente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelDatosVehiculoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(campoPatente, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelDatosVehiculoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(comboBoxCochera, javax.swing.GroupLayout.Alignment.LEADING, 0, 151, Short.MAX_VALUE)
                        .addComponent(comboBoxModelo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(comboBoxMarca, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(comboBoxTipo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(comboBoxColor, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(chooserAnio, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelDatosVehiculoLayout.setVerticalGroup(
            panelDatosVehiculoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDatosVehiculoLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panelDatosVehiculoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaPatente)
                    .addComponent(campoPatente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelDatosVehiculoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaColor)
                    .addComponent(comboBoxColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelDatosVehiculoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(etiquetaAño)
                    .addComponent(chooserAnio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelDatosVehiculoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaTipo)
                    .addComponent(comboBoxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelDatosVehiculoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaMarca)
                    .addComponent(comboBoxMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelDatosVehiculoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaModelo)
                    .addComponent(comboBoxModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelDatosVehiculoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaCochera)
                    .addComponent(comboBoxCochera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Datos del Vehiculo", panelDatosVehiculo);

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        botonActualizar.setText("Actualizar Cliente");
        botonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarActionPerformed(evt);
            }
        });

        botonGuardar.setText("Guardar Vehiculo");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonAgregar.setText("Agregar Vehiculo");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonAgregar)
                .addGap(18, 18, 18)
                .addComponent(botonGuardar)
                .addGap(18, 18, 18)
                .addComponent(botonActualizar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(botonSalir)
                .addContainerGap())
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 483, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonSalir)
                    .addComponent(botonActualizar)
                    .addComponent(botonGuardar)
                    .addComponent(botonAgregar))
                .addGap(0, 11, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
         dispose();
    }//GEN-LAST:event_botonSalirActionPerformed

    private void jTabbedPane1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTabbedPane1FocusGained
        
    }//GEN-LAST:event_jTabbedPane1FocusGained

    private void botonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarActionPerformed
        Cliente clienteupd = new Cliente();
        DireccionDAO diredao = new DireccionDAO();
        ClienteDAO clieDAO = new ClienteDAO();

        clienteupd.setIdpersona(cliente.getIdpersona());
        clienteupd.setCuil(Integer.parseInt(campoCUIL.getText()));
        clienteupd.setNombre(campoNombre.getText());
        clienteupd.setApellido(campoApellido.getText());
        clienteupd.setF_nacim((Date) campoFechaNacimiento.getDate());
        clienteupd.setEmail(campoEmail.getText());
        clienteupd.setTelefono1(campoTelefono1.getText());
        clienteupd.setTelefono2(campoTelefono2.getText());
        clienteupd.setDireccion((Direccion) diredao.getDireccionxID(cliente.getDireccion().getIddireccion()));
        clienteupd.setIddominio(0);
        clienteupd.setIdcochera(0);
        System.out.println(clienteupd.toString());

        if (clieDAO.ModificarCliente(clienteupd)){
            JOptionPane.showMessageDialog(rootPane, "El Cliente fue actualizado con exito!");
            botonActualizar.setEnabled(false);
            dispose();

        }else
        {
            JOptionPane.showMessageDialog(rootPane, "Algo falló al actualizar el Cliente, intentelo nuevamente!");
        }

    }//GEN-LAST:event_botonActualizarActionPerformed

    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        VehiculoDAO autodao = new VehiculoDAO();
        Vehiculo auto = new Vehiculo();
        auto.setPatente(campoPatente.getText());
        auto.setTipo((Tipo) (comboBoxTipo.getSelectedItem()));
        auto.setColor((Entidades.Color) (comboBoxColor.getSelectedItem()));
        auto.setAnio(chooserAnio.getYear());
        auto.setMarca((Marca) comboBoxMarca.getSelectedItem());
        auto.setModelo((Modelo) comboBoxModelo.getSelectedItem());
        auto.setIdpersona(cliente.getIdpersona());
        Cochera cochera = new Cochera();
        cochera.setIdcochera(5);
        
        if (autodao.agregarVehiculo(auto,cochera)) {
            mostrarVehiculos();
            JOptionPane.showMessageDialog(rootPane, "El VEHICULO fue Ingresado con exito");
            inicializarComponentes(false);
            botonAgregar.setEnabled(true);
            botonGuardar.setEnabled(false);

        } else {
            System.out.println("fallo el insert de Vehiculo en GUI");
        }
    }//GEN-LAST:event_botonGuardarActionPerformed

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        botonAgregar.setEnabled(false);
        botonGuardar.setEnabled(true);
        inicializarComponentes(true);
    }//GEN-LAST:event_botonAgregarActionPerformed

    private void comboBoxModeloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxModeloActionPerformed
        Modelo modelo = new Modelo();
        modelo = (Modelo) comboBoxModelo.getSelectedItem();
        int idmod = modelo.getIdmodelo();
        actualizarModelo(idmod);
    }//GEN-LAST:event_comboBoxModeloActionPerformed

    private void comboBoxColorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxColorActionPerformed
        Color color = new Color();
        color = (Color) comboBoxColor.getSelectedItem();
        int idmod = color.getIdcolor();
        actualizarModelo(idmod);
    }//GEN-LAST:event_comboBoxColorActionPerformed

    private void comboBoxTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxTipoActionPerformed
        Modelo modelo = new Modelo();
        modelo = (Modelo) comboBoxModelo.getSelectedItem();
        int idmod = modelo.getIdmodelo();
        actualizarModelo(idmod);
    }//GEN-LAST:event_comboBoxTipoActionPerformed

    private void comboBoxMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxMarcaActionPerformed
        Marca marca = new Marca();
        marca = (Marca) comboBoxMarca.getSelectedItem();
        int idmodelo = marca.getIdmarca();
        actualizarModelo(idmodelo);
    }//GEN-LAST:event_comboBoxMarcaActionPerformed

    private void comboBoxCocheraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxCocheraActionPerformed
        Cochera cochera = new Cochera();
        cochera = (Cochera) comboBoxCochera.getSelectedItem();
        //actualizarModelo();//Arrglar
    }//GEN-LAST:event_comboBoxCocheraActionPerformed

    private void comboBoxProvinciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxProvinciaActionPerformed
        Provincia p = new Provincia();
        p = (Provincia) comboBoxProvincia.getSelectedItem();
        int idp = p.getIdprovincia();
        actualizarLocalidad(idp);
    }//GEN-LAST:event_comboBoxProvinciaActionPerformed

    private void comboBoxLocalidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxLocalidadActionPerformed
        Localidad l = new Localidad();
        l = (Localidad) comboBoxLocalidad.getSelectedItem();
        double idmod = l.getIdlocalidad();
        actualizarModelo((int) idmod);
    }//GEN-LAST:event_comboBoxLocalidadActionPerformed

    private void tablaVehiculoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaVehiculoMouseClicked
        Vehiculo auto = new Vehiculo();
        VehiculoDAO autoDAO = new VehiculoDAO();
        int idauto = Integer.parseInt(tablaVehiculo.getValueAt(tablaVehiculo.getSelectedRow(), 0).toString());
        auto = autoDAO.getvehiculoxID(idauto);

        campoPatente.setText(auto.getPatente());actualizarCombo(comboBoxTipo, auto.getTipo().getDescripcion(), Tipo.class);      actualizarCombo(comboBoxColor, auto.getColor().getDescripcion(), Color.class);
        chooserAnio.setYear(auto.getAnio());
        actualizarCombo(comboBoxMarca, auto.getMarca().getDescripcion(), Marca.class);
        actualizarCombo(comboBoxModelo, auto.getModelo().getDescripcion(), Modelo.class);
    }//GEN-LAST:event_tablaVehiculoMouseClicked

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonActualizar;
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JButton botonSalir;
    private javax.swing.JTextField campoApellido;
    private javax.swing.JTextField campoCP;
    private javax.swing.JTextField campoCUIL;
    private javax.swing.JTextField campoCalle;
    private javax.swing.JTextField campoDepartamento;
    private javax.swing.JTextField campoEmail;
    private com.toedter.calendar.JDateChooser campoFechaNacimiento;
    private javax.swing.JTextField campoNombre;
    private javax.swing.JTextField campoNumero;
    private javax.swing.JTextField campoPatente;
    private javax.swing.JTextField campoPiso;
    private javax.swing.JTextField campoTelefono1;
    private javax.swing.JTextField campoTelefono2;
    private com.toedter.calendar.JYearChooser chooserAnio;
    private javax.swing.JComboBox<String> comboBoxCochera;
    private javax.swing.JComboBox<String> comboBoxColor;
    private javax.swing.JComboBox<String> comboBoxLocalidad;
    private javax.swing.JComboBox<String> comboBoxMarca;
    private javax.swing.JComboBox<String> comboBoxModelo;
    private javax.swing.JComboBox<String> comboBoxProvincia;
    private javax.swing.JComboBox<String> comboBoxTipo;
    private javax.swing.JLabel etiquetaApellido;
    private javax.swing.JLabel etiquetaAño;
    private javax.swing.JLabel etiquetaCP;
    private javax.swing.JLabel etiquetaCUIL;
    private javax.swing.JLabel etiquetaCalle;
    private javax.swing.JLabel etiquetaCochera;
    private javax.swing.JLabel etiquetaColor;
    private javax.swing.JLabel etiquetaDepartamento;
    private javax.swing.JLabel etiquetaEmail;
    private javax.swing.JLabel etiquetaLocalidad;
    private javax.swing.JLabel etiquetaMarca;
    private javax.swing.JLabel etiquetaModelo;
    private javax.swing.JLabel etiquetaNacimiento;
    private javax.swing.JLabel etiquetaNombre;
    private javax.swing.JLabel etiquetaNuemero;
    private javax.swing.JLabel etiquetaPatente;
    private javax.swing.JLabel etiquetaPiso;
    private javax.swing.JLabel etiquetaProvincia;
    private javax.swing.JLabel etiquetaTelefono1;
    private javax.swing.JLabel etiquetaTelefono2;
    private javax.swing.JLabel etiquetaTipo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel panelDatosVehiculo;
    private javax.swing.JPanel panelDireccion;
    private javax.swing.JPanel panelPrincipal;
    private javax.swing.JTable tablaVehiculo;
    // End of variables declaration//GEN-END:variables
}
