
package GUI;

import DAO.RegistroDAO;
import Entidades.Registro;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;   


public class ListarRegistrosGUI extends javax.swing.JDialog {

    
    public ListarRegistrosGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        cargarRegistros();
    }
    
    private void cargarRegistros() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Id del Registro");
        modelo.addColumn("Patente");
        modelo.addColumn("Titular");
        modelo.addColumn("Fecha");
        modelo.addColumn("Hora");
        modelo.addColumn("E/S");

        RegistroDAO regDAO = new RegistroDAO();
        LinkedList<Registro> listareg = regDAO.getAllRegistros();

        Object[] datos = new Object[6];
        for (Registro dato : listareg) {
            datos[0] = dato.getIdregistro();
            datos[1] = dato.getPatente();
            datos[2] = dato.getTitular();
            datos[3] = dato.getFecha();
            datos[4] = dato.getHora();
            datos[5] = dato.isES();
            datos[5] = (datos[5] == Boolean.TRUE) ? "Entrada" : "Salida";

            modelo.addRow(datos);
        }
        tablaListarRegistros.setModel(modelo);

        TableColumn columna1 = tablaListarRegistros.getColumnModel().getColumn(0);
        TableColumn columna2 = tablaListarRegistros.getColumnModel().getColumn(1);
        TableColumn columna3 = tablaListarRegistros.getColumnModel().getColumn(2);
        TableColumn columna4 = tablaListarRegistros.getColumnModel().getColumn(3);
        TableColumn columna5 = tablaListarRegistros.getColumnModel().getColumn(4);
        TableColumn columna6 = tablaListarRegistros.getColumnModel().getColumn(5);

        
        tablaListarRegistros.setAutoResizeMode(tablaListarRegistros.AUTO_RESIZE_NEXT_COLUMN);
        TableColumnModel columnModel = tablaListarRegistros.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(50);
        columnModel.getColumn(1).setPreferredWidth(100);
        columnModel.getColumn(2).setPreferredWidth(200);
        columnModel.getColumn(3).setPreferredWidth(200);
        columnModel.getColumn(4).setPreferredWidth(200);
        columnModel.getColumn(5).setPreferredWidth(200);
    }
    
    private void exportarRegistro() {
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaListarRegistros = new javax.swing.JTable();
        botonSalir = new javax.swing.JButton();
        botonExportar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        tablaListarRegistros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tablaListarRegistros);

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        botonExportar.setText("Exportar Registro");
        botonExportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonExportarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 605, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(botonSalir)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(botonExportar, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(botonExportar)
                .addGap(18, 18, 18)
                .addComponent(botonSalir)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonExportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonExportarActionPerformed
        RegistroDAO rdao = new RegistroDAO();
        LinkedList<Registro> listaregistros = rdao.getAllRegistros();

        FileWriter fw = null;
        JFileChooser fch = new JFileChooser();
        int seleccion = fch.showSaveDialog(this);

        if (seleccion == (JFileChooser.CANCEL_OPTION)) {
            return;
        }

        File archivoexportado = (fch.getSelectedFile());
        try {
            fw = new FileWriter(archivoexportado);
            BufferedWriter bw = new BufferedWriter(fw);

            for (Registro re : listaregistros) {
                bw.write(re.getIdregistro() + ";");
                bw.write(re.getPatente() + ";");
                bw.write(re.getTitular() + ";");
                bw.write(re.getFecha() + ";");
                bw.write(re.getHora() + ";");
                bw.write(((re.isES()) == Boolean.TRUE) ? "Entrada" : "Salida");
                bw.newLine();
            }
            bw.close();
            fw.close();
        } catch (IOException ex) {
            Logger.getLogger(ListarRegistrosGUI.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fw.close();
            } catch (IOException ex) {
                Logger.getLogger(ListarRegistrosGUI.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }//GEN-LAST:event_botonExportarActionPerformed

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
        dispose(); 
    }//GEN-LAST:event_botonSalirActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonExportar;
    private javax.swing.JButton botonSalir;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaListarRegistros;
    // End of variables declaration//GEN-END:variables
}
