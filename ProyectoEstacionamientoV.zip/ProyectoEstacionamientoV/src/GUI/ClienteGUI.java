
package GUI;

import DAO.ClienteDAO;
import DAO.DireccionDAO;
import DAO.ProvinciaDAO;
import DAO.UsuarioDAO;
import Entidades.Cliente;
import Entidades.Direccion;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.util.LinkedList;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class ClienteGUI extends javax.swing.JDialog {
    public static int idCliente;

    
    public ClienteGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        mostrarClientes();
    }

    private void mostrarClientes() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Id del Cliente");
        modelo.addColumn("Cuil");
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido");
        modelo.addColumn("F_nacim");
        modelo.addColumn("Email");
        modelo.addColumn("Telefono1");
        modelo.addColumn("Telefono2");
        modelo.addColumn("Telefono3");
        modelo.addColumn("Calle");
        modelo.addColumn("numero");
        modelo.addColumn("piso");
        modelo.addColumn("Departamento");
        modelo.addColumn("cp");
        modelo.addColumn("localidad");
        modelo.addColumn("Provincia");
        modelo.addColumn("Iddominio");
        modelo.addColumn("Idcochera");

        ClienteDAO clidao = new ClienteDAO();
        LinkedList<Cliente> lista = new LinkedList<Cliente>();
        lista = clidao.getAllClientes();
      
                
        Object[] datos = new Object[18];
        for (Cliente dato : lista) {
            datos[0] = dato.getIdpersona();
            datos[1] = dato.getCuil();
            datos[2] = dato.getNombre();
            datos[3] = dato.getApellido();
            datos[4] = dato.getF_nacim();
            datos[5] = dato.getEmail();
            datos[6] = dato.getTelefono1();
            datos[7] = dato.getTelefono2();
            datos[8] = dato.getTelefono3();
            datos[9] = dato.getDireccion().getCalle();
            datos[10] = dato.getDireccion().getNumero();
            datos[11] = dato.getDireccion().getPiso();
            datos[12] = dato.getDireccion().getDepartamento();
            datos[13] = dato.getDireccion().getCp();
            datos[14] = dato.getDireccion().getLocalidad().getNombre();
            datos[15] = dato.getDireccion().getProvincia().getNombre();
            datos[16] = dato.getIddominio();
            datos[17] = dato.getIdcochera();
            modelo.addRow(datos);
        }
        tablaCliente.setModel(modelo);
        
        TableColumn columna1 = tablaCliente.getColumnModel().getColumn(0);
        TableColumn columna2 = tablaCliente.getColumnModel().getColumn(1);
        TableColumn columna3 = tablaCliente.getColumnModel().getColumn(2);
        TableColumn columna4 = tablaCliente.getColumnModel().getColumn(3);
        TableColumn columna5 = tablaCliente.getColumnModel().getColumn(4);
        TableColumn columna6 = tablaCliente.getColumnModel().getColumn(5);
        TableColumn columna7 = tablaCliente.getColumnModel().getColumn(6);
        TableColumn columna8 = tablaCliente.getColumnModel().getColumn(7);
        TableColumn columna9 = tablaCliente.getColumnModel().getColumn(8);
        TableColumn columna10 = tablaCliente.getColumnModel().getColumn(9);
        TableColumn columna11 = tablaCliente.getColumnModel().getColumn(10);
        TableColumn columna12 = tablaCliente.getColumnModel().getColumn(11);
        TableColumn columna13 = tablaCliente.getColumnModel().getColumn(12);
        TableColumn columna14 = tablaCliente.getColumnModel().getColumn(13);
        TableColumn columna15 = tablaCliente.getColumnModel().getColumn(14);
        TableColumn columna16 = tablaCliente.getColumnModel().getColumn(15);
        TableColumn columna17 = tablaCliente.getColumnModel().getColumn(16);
        TableColumn columna18 = tablaCliente.getColumnModel().getColumn(17);
        
    }
    
     void exportarClientes() {
        JPanel contenedor = new JPanel();
        contenedor.setLayout(null);
        setContentPane(contenedor);

        ClienteDAO cdao = new ClienteDAO();
        LinkedList<Cliente> listacli = cdao.getAllClientes();

        FileWriter fw = null;
        JFileChooser fch = new JFileChooser();
        int seleccion = fch.showSaveDialog(contenedor);

        if (seleccion == (JFileChooser.APPROVE_OPTION)) {
            File archivoexportado = (fch.getSelectedFile());
            try {
                fw = new FileWriter(archivoexportado);
                BufferedWriter bw = new BufferedWriter(fw);
                for (Cliente cliente : listacli) {
                    bw.write(cliente.getCuil() + ";");
                    bw.write(cliente.getNombre() + ";");
                    bw.write(cliente.getApellido() + ";");
                    bw.write(cliente.getF_nacim() + ";");
                    bw.write(cliente.getEmail() + ";");
                    bw.write(cliente.getTelefono1() + ";");
                    bw.write(cliente.getTelefono2() + ";");
                    bw.write(cliente.getTelefono3() + ";");
                    bw.write(cliente.getDireccion().getCalle() + ";");
                    bw.write(cliente.getDireccion().getNumero() + ";");
                    bw.write(cliente.getDireccion().getPiso() + ";");
                    bw.write(cliente.getDireccion().getDepartamento() + ";");
                    bw.write(cliente.getDireccion().getLocalidad().getNombre() + ";");
                    bw.write(cliente.getDireccion().getProvincia().getNombre() + ";");
                    bw.write(cliente.getIdcochera()+";");
                    bw.newLine();
                }
                bw.close();
            } catch (IOException ex) {
                System.out.println("Fallo la exportacion de datos del Cliente");
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaCliente = new javax.swing.JTable();
        botonSalir = new javax.swing.JButton();
        botonAgregar = new javax.swing.JButton();
        botonEditar = new javax.swing.JButton();
        botonExportar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        tablaCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaClienteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaCliente);

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        botonAgregar.setText("Agregar");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        botonEditar.setText("Editar");
        botonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEditarActionPerformed(evt);
            }
        });

        botonExportar.setText("Exportar");
        botonExportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonExportarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 582, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonAgregar)
                .addGap(18, 18, 18)
                .addComponent(botonEditar)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(botonSalir))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonExportar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAgregar)
                    .addComponent(botonEditar)
                    .addComponent(botonExportar))
                .addGap(18, 18, 18)
                .addComponent(botonSalir)
                .addGap(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_botonSalirActionPerformed

    private void tablaClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaClienteMouseClicked
        int idrow;
 
        idrow = tablaCliente.getSelectedRow();
        if (idCliente < 0) {
            System.out.println("Salio por la tabla");
            return;
        } else {
            idCliente = Integer.parseInt(tablaCliente.getValueAt(idrow, 0).toString());
          
        }
    }//GEN-LAST:event_tablaClienteMouseClicked

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        JFrame frame = new JFrame();
        ClienteFichaGUI Ficha = new ClienteFichaGUI(frame,true);
        Ficha.pack();
        Ficha.setSize(this.getWidth()/1/2, this.getHeight()-50);
        Ficha.setLocationRelativeTo(null);
        Ficha.setVisible(true);
    }//GEN-LAST:event_botonAgregarActionPerformed

    private void botonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEditarActionPerformed
        JFrame frame = new JFrame();
        ClienteFichaGUI Ficha = new ClienteFichaGUI(frame,true);
        Ficha.pack();
        Ficha.setSize(this.getWidth() / 1 / 2, this.getHeight() - 50);
        Ficha.setLocationRelativeTo(null);
        Ficha.setVisible(true);
    }//GEN-LAST:event_botonEditarActionPerformed

    private void botonExportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonExportarActionPerformed
        exportarClientes();
    }//GEN-LAST:event_botonExportarActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonEditar;
    private javax.swing.JButton botonExportar;
    private javax.swing.JButton botonSalir;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaCliente;
    // End of variables declaration//GEN-END:variables
}
