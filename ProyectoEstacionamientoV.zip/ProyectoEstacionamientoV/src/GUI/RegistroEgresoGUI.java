
package GUI;

import DAO.CocheraDAO;
import DAO.VehiculoDAO;
import Entidades.Vehiculo;
import java.awt.Dimension;
import java.util.Date;
import javax.swing.JOptionPane;

public class RegistroEgresoGUI extends javax.swing.JDialog {
    
    Vehiculo v;

   public RegistroEgresoGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        Date d = new Date();
        initComponents();
        this.setResizable(true);
        this.setSize(new Dimension(300,250));
        this.setMinimumSize(new Dimension(300,250)); 
        campoVehiculo.setVisible(false);
       
        
        
        campoPatente.requestFocus();
        campoPatente.selectAll();
       
        campoFecha.setText("   "+d.getDate()+"/"+(d.getMonth()+1)+"/"+(d.getYear()+1900));
        campoHora.setText("   "+d.getHours()+" : "+d.getMinutes()+" : "+d.getSeconds()+" . ");
       
       
        botonRegistrar.setEnabled(true);
   
            System.out.println("Fecha: "+d.getDate()+"/"+(d.getMonth()+1)+"/"+(d.getYear()+1900));
            System.out.println("Hora: "+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds());
    
    
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        campoFecha = new javax.swing.JTextField();
        campoHora = new javax.swing.JTextField();
        campoPatente = new javax.swing.JTextField();
        campoVehiculo = new javax.swing.JTextField();
        botonBuscar = new javax.swing.JButton();
        botonRegistrar = new javax.swing.JButton();
        botonCancelar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Baskerville Old Face", 3, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Fecha:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 60, 40));

        jLabel3.setFont(new java.awt.Font("Baskerville Old Face", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Hora:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, 50, 30));

        jLabel4.setFont(new java.awt.Font("Baskerville Old Face", 3, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Patente:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, 70, 30));

        jLabel5.setFont(new java.awt.Font("Baskerville Old Face", 3, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Vehiculo:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, 80, 20));

        campoFecha.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        campoFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoFechaActionPerformed(evt);
            }
        });
        campoFecha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                campoFechaKeyPressed(evt);
            }
        });
        getContentPane().add(campoFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, 150, 30));

        campoHora.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        campoHora.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoHoraActionPerformed(evt);
            }
        });
        campoHora.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                campoHoraKeyPressed(evt);
            }
        });
        getContentPane().add(campoHora, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, 150, 30));

        campoPatente.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        campoPatente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                campoPatenteKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campoPatenteKeyTyped(evt);
            }
        });
        getContentPane().add(campoPatente, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 230, 150, 30));

        campoVehiculo.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        campoVehiculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoVehiculoActionPerformed(evt);
            }
        });
        getContentPane().add(campoVehiculo, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 270, 150, 30));

        botonBuscar.setText("Buscar");
        botonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(botonBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(313, 230, 90, 40));

        botonRegistrar.setText("Registrar");
        botonRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarActionPerformed(evt);
            }
        });
        getContentPane().add(botonRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 330, 90, 40));

        botonCancelar.setText("Cancelar");
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });
        getContentPane().add(botonCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(375, 430, 90, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondoMenu.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void campoFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoFechaActionPerformed
        
    }//GEN-LAST:event_campoFechaActionPerformed

    private void campoVehiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoVehiculoActionPerformed
       
    }//GEN-LAST:event_campoVehiculoActionPerformed

    private void botonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarActionPerformed
        VehiculoDAO vdao = new VehiculoDAO();

        if (campoPatente.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar una Patente válida");
            campoPatente.requestFocus();
            campoPatente.selectAll();
            return;
        } else {
            v = (vdao.getvehiculoxPatente(campoPatente.getText().trim()));
            String p = v.getPatente();
            if (p != null) {
                
                campoVehiculo.setVisible(true);
                campoVehiculo.setText(v.getMarca().getDescripcion() + " - " + v.getModelo().getDescripcion()+" - "+ v.getColor().getDescripcion() );
                botonRegistrar.setEnabled(true);

            } else {
                campoVehiculo.setText("NO se ha encontrado el Vehiculo");
                campoPatente.requestFocus();
                campoPatente.selectAll();
                return;

            }
        }
    }//GEN-LAST:event_botonBuscarActionPerformed

    private void botonRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegistrarActionPerformed
         CocheraDAO cdao = new CocheraDAO();
        System.out.println(v.toString());
        if (cdao.outCochera(v)) {
            JOptionPane.showMessageDialog(null, "REGISTRO EXITOSO");
            botonRegistrar.setEnabled(false);
            campoPatente.selectAll();
            campoPatente.setText("");
            campoVehiculo.setText("");
            campoPatente.requestFocus();
        } else {
            JOptionPane.showMessageDialog(null, "REGISTRO INVALIDO");
            campoPatente.requestFocus();
            campoPatente.selectAll();

        } 
    }//GEN-LAST:event_botonRegistrarActionPerformed

    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarActionPerformed
        this.dispose();
    }//GEN-LAST:event_botonCancelarActionPerformed

    private void campoPatenteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoPatenteKeyPressed
        campoVehiculo.setText("");
    }//GEN-LAST:event_campoPatenteKeyPressed

    private void campoFechaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoFechaKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoFechaKeyPressed

    private void campoHoraKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoHoraKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoHoraKeyPressed

    private void campoPatenteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoPatenteKeyTyped
        String cadena= (campoPatente.getText()).toUpperCase();
        campoPatente.setText(cadena);
    }//GEN-LAST:event_campoPatenteKeyTyped

    private void campoHoraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoHoraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoHoraActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonBuscar;
    private javax.swing.JButton botonCancelar;
    private javax.swing.JButton botonRegistrar;
    private javax.swing.JTextField campoFecha;
    private javax.swing.JTextField campoHora;
    private javax.swing.JTextField campoPatente;
    private javax.swing.JTextField campoVehiculo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
