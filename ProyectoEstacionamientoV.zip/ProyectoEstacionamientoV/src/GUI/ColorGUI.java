
package GUI;

import DAO.ColorDAO;
import Entidades.Color;
import Entidades.Marca;
import java.util.LinkedList;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class ColorGUI extends javax.swing.JDialog {
    
    private boolean modificar = false;
    private int idColor;

    
    public ColorGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        mostrarColor();
        botonGuardar.setEnabled(false);
        botonModificar.setEnabled(false);
        campoCodigo.setEnabled(false);
        campoDescripcion.setEnabled(false);
    }
    
     private void mostrarColor() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Id Color");
        modelo.addColumn("Nombre");

        ColorDAO coldao = new ColorDAO();
        LinkedList<Color> lista = new LinkedList<Color>();
        lista = coldao.getAllColores();

        Object[] datos = new Object[2];
        for (Color dato : lista) {
            datos[0] = dato.getIdcolor();
            datos[1] = dato.getDescripcion();
            modelo.addRow(datos);
        }
        tablaColores.setModel(modelo);

        TableColumn columna1 = tablaColores.getColumnModel().getColumn(0);
        TableColumn columna2 = tablaColores.getColumnModel().getColumn(1);
        tablaColores.setAutoResizeMode(tablaColores.AUTO_RESIZE_NEXT_COLUMN);
        TableColumnModel columnModel = tablaColores.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(25);
        columnModel.getColumn(1).setPreferredWidth(1200);
    }

     private void GuardarColor(Color color, boolean modificar) {

        ColorDAO colordao = new ColorDAO();

        if (modificar) {
            System.out.println(color.toString());
            if (colordao.modificarColor(color)) {
                mostrarColor();
                botonAgregar.setEnabled(false);
            } else {
                System.out.println("Fallo la modificacion de la Marca, intentelo nuevamente!");
            }
        } else {
            if (colordao.agregarColor(color)) {
                mostrarColor();
                botonAgregar.setEnabled(false);
            } else {
                System.out.println("Fallo el ingreso de Marca, intentelo nuevamente!");
            }
        }

        campoDescripcion.setEnabled(false);
        botonAgregar.setEnabled(true);
        botonGuardar.setEnabled(false);
        modificar = false;
    }
     
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaColores = new javax.swing.JTable();
        botonSalir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        campoCodigo = new javax.swing.JTextField();
        campoDescripcion = new javax.swing.JTextField();
        botonGuardar = new javax.swing.JButton();
        botonAgregar = new javax.swing.JButton();
        botonModificar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        tablaColores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaColores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaColoresMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaColores);

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        jLabel1.setText("Codigo:");

        jLabel2.setText("Descripcion:");

        campoDescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoDescripcionActionPerformed(evt);
            }
        });

        botonGuardar.setText("Guardar");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonAgregar.setText("Agregar");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        botonModificar.setText("Modificar");
        botonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonModificarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 596, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonModificar)
                        .addGap(29, 29, 29)
                        .addComponent(botonAgregar)
                        .addGap(28, 28, 28)
                        .addComponent(botonGuardar)
                        .addGap(18, 18, 18)
                        .addComponent(botonSalir))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(jLabel2))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(campoCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(campoDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(campoCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(campoDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonSalir)
                    .addComponent(botonGuardar)
                    .addComponent(botonAgregar)
                    .addComponent(botonModificar))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
        dispose(); 
    }//GEN-LAST:event_botonSalirActionPerformed

    private void botonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonModificarActionPerformed
        botonAgregar.setEnabled(false);
        botonGuardar.setEnabled(true);
        campoDescripcion.setEnabled(true);
        botonModificar.setEnabled(false);
        modificar = true;
    }//GEN-LAST:event_botonModificarActionPerformed

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        botonGuardar.setEnabled(true);
        campoDescripcion.setEnabled(true);
        botonAgregar.setEnabled(false);    
    }//GEN-LAST:event_botonAgregarActionPerformed

    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
           Color color = new Color();

        if (modificar) {
            if (campoDescripcion.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Debe completar el campo Descripcion");
                campoDescripcion.setRequestFocusEnabled(true);
            } else {
                color.setIdcolor(idColor);
                color.setDescripcion(campoDescripcion.getText());
                GuardarColor(color, true);
            }
        } else {
            if (campoDescripcion.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Debe completar el campo Descripcion");
                campoDescripcion.setRequestFocusEnabled(true);
            } else {
                color.setDescripcion(campoDescripcion.getText());
                GuardarColor(color, false);
            }
        }
    
    }//GEN-LAST:event_botonGuardarActionPerformed

    private void tablaColoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaColoresMouseClicked
        Color color = new Color();
        ColorDAO colordao = new ColorDAO();
        idColor = Integer.parseInt(tablaColores.getValueAt(tablaColores.getSelectedRow(), 0).toString());
        color = colordao.getcolorxID(idColor);

        campoCodigo.setText(String.valueOf(color.getIdcolor()));
        campoDescripcion.setText(color.getDescripcion());
        botonModificar.setEnabled(true);
        botonAgregar.setEnabled(false);
    }//GEN-LAST:event_tablaColoresMouseClicked

    private void campoDescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoDescripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoDescripcionActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JButton botonModificar;
    private javax.swing.JButton botonSalir;
    private javax.swing.JTextField campoCodigo;
    private javax.swing.JTextField campoDescripcion;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaColores;
    // End of variables declaration//GEN-END:variables
}
