
package GUI;

import javax.swing.UIManager;


public class MenuPrincipal extends javax.swing.JFrame {

   
    public MenuPrincipal() {
        initComponents();
        setVisible(true);
        this.setExtendedState(MAXIMIZED_BOTH);
        this.pack();
        
        /*this.setDefaultLookAndFeelDecorated(true);
        try {
            UIManager.setLookAndFeel("com.jtattoo.plaf.noire.NoireLookAndFeel");
        } catch (Exception e) {
        }*/
        
    }
 
   
    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        botonIngresa = new javax.swing.JButton();
        botonEgreso = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuSistemas = new javax.swing.JMenu();
        menuItemUsuarios = new javax.swing.JMenuItem();
        menuItemSalir = new javax.swing.JMenuItem();
        menuClientes = new javax.swing.JMenu();
        menuItemFichas = new javax.swing.JMenuItem();
        menuTablas = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        menuItemVehiculo2 = new javax.swing.JMenuItem();
        menuItemMarca = new javax.swing.JMenuItem();
        menuItemCcohera = new javax.swing.JMenuItem();
        menuItemTipo = new javax.swing.JMenuItem();
        menuItemModelo = new javax.swing.JMenuItem();
        menuItemColor = new javax.swing.JMenuItem();
        menuItemRegistros = new javax.swing.JMenuItem();

        jMenu1.setText("File");
        jMenuBar2.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar2.add(jMenu2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        botonIngresa.setFont(new java.awt.Font("Baskerville Old Face", 3, 36)); // NOI18N
        botonIngresa.setText("Ingreso");
        botonIngresa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonIngresaActionPerformed(evt);
            }
        });
        getContentPane().add(botonIngresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 180, 70));

        botonEgreso.setFont(new java.awt.Font("Baskerville Old Face", 3, 36)); // NOI18N
        botonEgreso.setText("Egreso");
        botonEgreso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEgresoActionPerformed(evt);
            }
        });
        getContentPane().add(botonEgreso, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 190, 190, 70));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondoMenu.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 493, -1));

        menuSistemas.setText("Sistema");
        menuSistemas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSistemasActionPerformed(evt);
            }
        });

        menuItemUsuarios.setText("Usuarios");
        menuItemUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemUsuariosActionPerformed(evt);
            }
        });
        menuSistemas.add(menuItemUsuarios);

        menuItemSalir.setText("Salir del sistema");
        menuItemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemSalirActionPerformed(evt);
            }
        });
        menuSistemas.add(menuItemSalir);

        jMenuBar1.add(menuSistemas);

        menuClientes.setText("Clientes");
        menuClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuClientesActionPerformed(evt);
            }
        });

        menuItemFichas.setText("Fichas");
        menuItemFichas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemFichasActionPerformed(evt);
            }
        });
        menuClientes.add(menuItemFichas);

        jMenuBar1.add(menuClientes);

        menuTablas.setText("Tablas");
        menuTablas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuTablasActionPerformed(evt);
            }
        });

        jMenu3.setText("Vehiculo");
        jMenu3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu3ActionPerformed(evt);
            }
        });

        menuItemVehiculo2.setText("Vehiculo");
        menuItemVehiculo2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemVehiculo2ActionPerformed(evt);
            }
        });
        jMenu3.add(menuItemVehiculo2);

        menuItemMarca.setText("Marca");
        menuItemMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemMarcaActionPerformed(evt);
            }
        });
        jMenu3.add(menuItemMarca);

        menuItemCcohera.setText("Cochera");
        menuItemCcohera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemCcoheraActionPerformed(evt);
            }
        });
        jMenu3.add(menuItemCcohera);

        menuItemTipo.setText("Tipo");
        menuItemTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemTipoActionPerformed(evt);
            }
        });
        jMenu3.add(menuItemTipo);

        menuItemModelo.setText("Modelo");
        menuItemModelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemModeloActionPerformed(evt);
            }
        });
        jMenu3.add(menuItemModelo);

        menuItemColor.setText("Color");
        menuItemColor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemColorActionPerformed(evt);
            }
        });
        jMenu3.add(menuItemColor);

        menuTablas.add(jMenu3);

        menuItemRegistros.setText("Registro ");
        menuItemRegistros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemRegistrosActionPerformed(evt);
            }
        });
        menuTablas.add(menuItemRegistros);

        jMenuBar1.add(menuTablas);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuSistemasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSistemasActionPerformed
        
    }//GEN-LAST:event_menuSistemasActionPerformed

    private void botonIngresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonIngresaActionPerformed
        RegistroIngresoGUI registroingreso = new RegistroIngresoGUI(this, true);
        registroingreso.pack();
        //registroingreso.setSize(this.getWidth(), this.getHeight());
        registroingreso.setLocation(150, 45);
        registroingreso.setVisible(true);
    }//GEN-LAST:event_botonIngresaActionPerformed

    private void botonEgresoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEgresoActionPerformed
        RegistroEgresoGUI registroegreso = new RegistroEgresoGUI(this, true);
        registroegreso.pack();
        //registroegreso.setSize(this.getWidth(), this.getHeight());
        registroegreso.setLocation(150, 45);
        registroegreso.setVisible(true);

    }//GEN-LAST:event_botonEgresoActionPerformed

    private void menuClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuClientesActionPerformed
        ClienteGUI cli = new ClienteGUI(this, true);
        cli.pack();
        //cli.setSize(this.getWidth(), this.getHeight()+50);
        cli.setLocation(-5, 45);
        cli.setVisible(true);

    }//GEN-LAST:event_menuClientesActionPerformed

    private void menuItemUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuItemUsuariosActionPerformed
        UsuarioGUI usr = new UsuarioGUI(this, true);
        usr.pack();
        //usr.setSize(this.getWidth()+60, this.getHeight()+100);  
        usr.setLocation(-5, 45);  
        usr.setVisible(true);
    }//GEN-LAST:event_menuItemUsuariosActionPerformed

    private void menuItemSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuItemSalirActionPerformed
       this.dispose();
    }//GEN-LAST:event_menuItemSalirActionPerformed

    private void menuItemFichasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuItemFichasActionPerformed
        ClienteGUI cli = new ClienteGUI(this, true);
        cli.pack();
        cli.setSize(this.getWidth()+500, this.getHeight());
        cli.setLocation(-5, 45);
        cli.setVisible(true);
    }//GEN-LAST:event_menuItemFichasActionPerformed

    private void menuTablasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuTablasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuTablasActionPerformed

    private void menuItemRegistrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuItemRegistrosActionPerformed
        ListarRegistrosGUI listaRegistros = new ListarRegistrosGUI(this, true);
        listaRegistros.pack();
        //listaRegistros.setSize(this.getWidth(), this.getHeight()+20);
        listaRegistros.setLocation(-5, 45);
        listaRegistros.setVisible(true);
    }//GEN-LAST:event_menuItemRegistrosActionPerformed

    private void jMenu3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenu3ActionPerformed

    private void menuItemVehiculo2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuItemVehiculo2ActionPerformed
        VehiculoGUI veh = new VehiculoGUI(this, true);
        veh.pack();
        //veh.setSize(this.getWidth(), this.getHeight()+60);
        veh.setLocation(-5, 45);
        veh.setVisible(true);

    }//GEN-LAST:event_menuItemVehiculo2ActionPerformed

    private void menuItemMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuItemMarcaActionPerformed
        MarcaGUI marca = new MarcaGUI(this, true);
        marca.pack();
        //marca.setSize(this.getWidth()+80, this.getHeight()+60);
        marca.setLocation(-5, 45);
        marca.setVisible(true);
    }//GEN-LAST:event_menuItemMarcaActionPerformed

    private void menuItemCcoheraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuItemCcoheraActionPerformed
        CocheraGUI cochera = new CocheraGUI(this, true);
        cochera.pack();
        //cochera.setSize(this.getWidth(), this.getHeight()+40);
        cochera.setLocation(-5, 45);
        cochera.setVisible(true);
    }//GEN-LAST:event_menuItemCcoheraActionPerformed

    private void menuItemTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuItemTipoActionPerformed
        TiposGUI tipo = new TiposGUI(this, true);
        tipo.pack();
        //tipo.setSize(this.getWidth()+120, this.getHeight()+80);
        tipo.setLocation(-5, 45);
        tipo.setVisible(true);
    }//GEN-LAST:event_menuItemTipoActionPerformed

    private void menuItemModeloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuItemModeloActionPerformed
        ModeloGUI Mod = new ModeloGUI(this, true);
        Mod.pack();
        //Mod.setSize(this.getWidth()+80, this.getHeight()+80);
        Mod.setLocation(-5, 45);
        Mod.setVisible(true);
    }//GEN-LAST:event_menuItemModeloActionPerformed

    private void menuItemColorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuItemColorActionPerformed
        ModeloGUI Mod = new ModeloGUI(this, true);
        Mod.pack();
        //Mod.setSize(this.getWidth()+80, this.getHeight()+80);
        Mod.setLocation(-5, 45);
        Mod.setVisible(true);
    }//GEN-LAST:event_menuItemColorActionPerformed

    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonEgreso;
    private javax.swing.JButton botonIngresa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenu menuClientes;
    private javax.swing.JMenuItem menuItemCcohera;
    private javax.swing.JMenuItem menuItemColor;
    private javax.swing.JMenuItem menuItemFichas;
    private javax.swing.JMenuItem menuItemMarca;
    private javax.swing.JMenuItem menuItemModelo;
    private javax.swing.JMenuItem menuItemRegistros;
    private javax.swing.JMenuItem menuItemSalir;
    private javax.swing.JMenuItem menuItemTipo;
    private javax.swing.JMenuItem menuItemUsuarios;
    private javax.swing.JMenuItem menuItemVehiculo2;
    private javax.swing.JMenu menuSistemas;
    private javax.swing.JMenu menuTablas;
    // End of variables declaration//GEN-END:variables
}
