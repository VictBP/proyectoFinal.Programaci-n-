
package GUI;

import DAO.CocheraDAO;
import DAO.VehiculoDAO;
import Entidades.Vehiculo;
import java.util.Date;
import javax.swing.JDialog;
import javax.swing.JOptionPane;


public class RegistroIngresoGUI extends javax.swing.JDialog {
    
    Vehiculo v;
    
    public RegistroIngresoGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        Date d = new Date();

        this.setResizable(false);
        campoPatente.requestFocus();
        campoPatente.selectAll();
        botonRegistrar.setEnabled(true);
        
        campoHora.setText("   "+d.getHours()+" : "+d.getMinutes()+" : "+d.getSeconds()+" . ");

    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        campoHora = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        campoPatente = new javax.swing.JTextField();
        botonRegistrar = new javax.swing.JToggleButton();
        botonBuscar = new javax.swing.JButton();
        campoAuto = new javax.swing.JLabel();
        botonSalir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Baskerville Old Face", 3, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Hora:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 100, 40));

        campoHora.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        getContentPane().add(campoHora, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, 200, 50));

        jLabel3.setFont(new java.awt.Font("Baskerville Old Face", 3, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Patente:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 140, 50));

        campoPatente.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        campoPatente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                campoPatenteKeyPressed(evt);
            }
        });
        getContentPane().add(campoPatente, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, 230, 50));

        botonRegistrar.setText("Registrar");
        botonRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarActionPerformed(evt);
            }
        });
        getContentPane().add(botonRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 410, 130, 50));

        botonBuscar.setText("Buscar");
        botonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(botonBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 260, 90, 40));

        campoAuto.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        campoAuto.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(campoAuto, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 330, 370, 60));

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });
        getContentPane().add(botonSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 20, -1, -1));

        jLabel1.setFont(new java.awt.Font("Baskerville Old Face", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondoMenu.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarActionPerformed
        VehiculoDAO vdao = new VehiculoDAO();

        if (campoPatente.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar una Patente válida");
            campoPatente.requestFocus();
            campoPatente.selectAll();
            return;
        } else {
            v = (vdao.getvehiculoxPatente(campoPatente.getText().trim()));
            String p = v.getPatente();
            if (p != null) {
                campoAuto.setText(v.getMarca().getDescripcion() + " - " + v.getModelo().getDescripcion()+" - "+ v.getColor().getDescripcion() );
                botonRegistrar.setEnabled(true);

            } else {
                campoAuto.setText("NO se ha encontrado el Vehiculo");
                campoPatente.requestFocus();
                campoPatente.selectAll();
                return;

            }
        }
    }//GEN-LAST:event_botonBuscarActionPerformed

    private void botonRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegistrarActionPerformed
        CocheraDAO cdao = new CocheraDAO();
        System.out.println(v.toString());
        if (cdao.updCochera(v)) {
            JOptionPane.showMessageDialog(null, "REGISTRO EXITOSO");
            botonRegistrar.setEnabled(false);
            campoPatente.selectAll();
            campoPatente.setText("");
            campoAuto.setText("");
            campoPatente.requestFocus();
        } else {
            JOptionPane.showMessageDialog(null, "REGISTRO INVALIDO");
            campoPatente.requestFocus();
            campoPatente.selectAll();

        }
    }//GEN-LAST:event_botonRegistrarActionPerformed

    private void campoPatenteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoPatenteKeyPressed
        campoAuto.setText("");
    }//GEN-LAST:event_campoPatenteKeyPressed

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
         this.dispose();
    }//GEN-LAST:event_botonSalirActionPerformed

 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonBuscar;
    private javax.swing.JToggleButton botonRegistrar;
    private javax.swing.JButton botonSalir;
    private javax.swing.JLabel campoAuto;
    private javax.swing.JTextField campoHora;
    private javax.swing.JTextField campoPatente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
