
package GUI;

import DAO.MarcaDAO;
import Entidades.Marca;
import java.util.LinkedList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class MarcaGUI extends javax.swing.JDialog {
    
    private boolean modificar = false;
    private int idMarca;

   
    public MarcaGUI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        mostrarMarcas();
        botonGuardar.setEnabled(false);
        botonModificar.setEnabled(false);
        campoDescripcion.setEnabled(false);
        campoIdMarca.setEnabled(false);
    }

    private void mostrarMarcas() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Id Marca");
        modelo.addColumn("Descripcion");

        MarcaDAO marcadao = new MarcaDAO();
        LinkedList<Marca> lista = new LinkedList<Marca>();
        lista = marcadao.getAllMarcas();

        Object[] datos = new Object[2];
        for (Marca dato : lista) {
            datos[0] = dato.getIdmarca();
            datos[1] = dato.getDescripcion();
            modelo.addRow(datos);
        }
        tablaMarca.setModel(modelo);
        TableColumn col = tablaMarca.getColumnModel().getColumn(0);
        TableColumn col2 = tablaMarca.getColumnModel().getColumn(1);
        tablaMarca.setAutoResizeMode(tablaMarca.AUTO_RESIZE_NEXT_COLUMN);
        TableColumnModel columnModel = tablaMarca.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(25);
        columnModel.getColumn(1).setPreferredWidth(1200);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaMarca = new javax.swing.JTable();
        etiquetaCodigo = new javax.swing.JLabel();
        etiquetaDescripcion = new javax.swing.JLabel();
        botonSalir = new javax.swing.JButton();
        campoCodigo = new javax.swing.JTextField();
        campoDescripcion = new javax.swing.JTextField();
        botonAgregar = new javax.swing.JButton();
        botonGuardar = new javax.swing.JButton();
        botonModificar = new javax.swing.JButton();
        campoIdMarca = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        jScrollPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane1MouseClicked(evt);
            }
        });

        tablaMarca.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaMarca.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMarcaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaMarca);

        etiquetaCodigo.setText("Codigo");

        etiquetaDescripcion.setText("Descripcion");

        botonSalir.setText("Salir");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        botonAgregar.setText("Agregar");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        botonGuardar.setText("Guardar");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonModificar.setText("Modificar");
        botonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonModificarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(etiquetaCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(campoIdMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(campoCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(etiquetaDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(campoDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 431, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 79, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(botonSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonModificar)
                .addGap(18, 18, 18)
                .addComponent(botonAgregar)
                .addGap(18, 18, 18)
                .addComponent(botonGuardar)
                .addGap(13, 13, 13))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoCodigo)
                    .addComponent(etiquetaCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoIdMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiquetaDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAgregar)
                    .addComponent(botonGuardar)
                    .addComponent(botonModificar))
                .addGap(9, 9, 9)
                .addComponent(botonSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
        dispose(); 
    }//GEN-LAST:event_botonSalirActionPerformed

    private void botonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonModificarActionPerformed
        botonAgregar.setEnabled(false);
        botonGuardar.setEnabled(true);
        campoDescripcion.setEnabled(true);
        botonModificar.setEnabled(false);
        modificar = true;
    }//GEN-LAST:event_botonModificarActionPerformed

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        botonGuardar.setEnabled(true);
        campoDescripcion.setEnabled(true);
        botonAgregar.setEnabled(false);
    }//GEN-LAST:event_botonAgregarActionPerformed
    
     private void GuardarMarca(Marca marca, boolean modificar) {

        MarcaDAO marcadao = new MarcaDAO();

        if (modificar) {
            System.out.println(marca.toString());
            if (marcadao.modificarMarca(marca)) {
                mostrarMarcas();
                botonAgregar.setEnabled(false);
            } else {
                System.out.println("Fallo la modificacion de la Marca");
            }
        } else {
            if (marcadao.agregarMarca(marca)) {
                mostrarMarcas();
                botonAgregar.setEnabled(false);
            } else {
                System.out.println("Fallo el ingreso de Marca");
            }
        }

        campoDescripcion.setEnabled(false);
        botonAgregar.setEnabled(true);
        botonGuardar.setEnabled(false);
        modificar = false;
    }
    
    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        Marca marca = new Marca();

        if (modificar) {
            if (campoDescripcion.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Debe completar el campo Descripcion");
                campoDescripcion.setRequestFocusEnabled(true);
            } else {
                marca.setIdmarca(idMarca);
                marca.setDescripcion(campoDescripcion.getText());
                GuardarMarca(marca, true);
            }
        } else {
            if (campoDescripcion.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Debe completar el campo Descripcion");
                campoDescripcion.setRequestFocusEnabled(true);
            } else {
                marca.setDescripcion(campoDescripcion.getText());
                GuardarMarca(marca, false);
            }
        }
    }//GEN-LAST:event_botonGuardarActionPerformed

    private void jScrollPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jScrollPane1MouseClicked

    private void tablaMarcaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMarcaMouseClicked
        Marca marca = new Marca();
        MarcaDAO marcadao = new MarcaDAO();
        idMarca = Integer.parseInt(tablaMarca.getValueAt(tablaMarca.getSelectedRow(), 0).toString());
        marca = marcadao.getMarcaxID(idMarca);

        campoIdMarca.setText(String.valueOf(marca.getIdmarca()));
        campoDescripcion.setText(marca.getDescripcion());
        botonModificar.setEnabled(true);
        botonAgregar.setEnabled(false);
        
    }//GEN-LAST:event_tablaMarcaMouseClicked

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JButton botonModificar;
    private javax.swing.JButton botonSalir;
    private javax.swing.JTextField campoCodigo;
    private javax.swing.JTextField campoDescripcion;
    private javax.swing.JTextField campoIdMarca;
    private javax.swing.JLabel etiquetaCodigo;
    private javax.swing.JLabel etiquetaDescripcion;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaMarca;
    // End of variables declaration//GEN-END:variables
}
