
package ParkingV;

import GUI.*;
import DAO.ColorDAO;

public class ParkinVictoria {
    
    public static void main(String[] args) {
      
        ColorDAO colordao = new ColorDAO();  
        LogingGUI log;      
        log = new LogingGUI();
        log.setVisible(true);                
        log.setLocationRelativeTo(null);     
        
    }
}
