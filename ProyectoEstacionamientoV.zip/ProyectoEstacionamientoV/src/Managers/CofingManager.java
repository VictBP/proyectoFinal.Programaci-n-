
package Managers;


public class CofingManager {
    
    public static final String host = "localhost";  
    public static final String db = "cfp36";
    public static final String usr = "root";
    public static final String pwd = "";
    public static final String port = "3306";
}
