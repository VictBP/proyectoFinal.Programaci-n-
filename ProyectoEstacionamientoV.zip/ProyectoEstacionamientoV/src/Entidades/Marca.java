
package Entidades;


public class Marca {
    
    private int idmarca;
  private String descripcion;  

    
    public int getIdmarca() {
        return idmarca;
    }

    
    public void setIdmarca(int idmarca) {
        this.idmarca = idmarca;
    }

    
    public String getDescripcion() {
        return descripcion;
    }

    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Marca(){

    }

    @Override
    public String toString() {
        return "Marca{" + "idmarca=" + idmarca + ", descripcion=" + descripcion + '}';
    }
}
