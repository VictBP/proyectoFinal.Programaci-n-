
package Entidades;


public class Vehiculocc {
    
   private int iddominio;
   private String patente;
   private Tipo tipo;
   private Color color;
   private int anio;
   private Marca marca;
   private Modelo modelo;
   private int idpersona;
   private String cochera;

    
    public int getIddominio() {
        return iddominio;
    }

    
    public void setIddominio(int iddominio) {
        this.iddominio = iddominio;
    }

    
    public String getPatente() {
        return patente;
    }

    
    public void setPatente(String patente) {
        this.patente = patente;
    }

    
    public Tipo getTipo() {
        return tipo;
    }

    
    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    
    public Color getColor() {
        return color;
    }

    
    public void setColor(Color color) {
        this.color = color;
    }

   
    public int getAnio() {
        return anio;
    }

    
    public void setAnio(int anio) {
        this.anio = anio;
    }

   
    public Marca getMarca() {
        return marca;
    }

    
    public void setMarca(Marca marca) {
        this.marca = marca;
    }

    
    public Modelo getModelo() {
        return modelo;
    }

    
    public void setModelo(Modelo modelo) {
        this.modelo = modelo;
    }

    
    public int getIdpersona() {
        return idpersona;
    }

    
    public void setIdpersona(int idpersona) {
        this.idpersona = idpersona;
    }

    
    public String getCochera() {
        return cochera;
    }

    
    public void setCochera(String cochera) {
        this.cochera = cochera;
    }
    } 


