
package Entidades;

import java.sql.Date;


public class Cliente {
    
    private int idpersona;
private int cuil;
private String nombre;
private String apellido;
private Date f_nacim;
private String email;
private String telefono1;
private String telefono2;
private String telefono3;
private Direccion direccion;
private int iddominio;
private int idcochera;


    
    public int getIdpersona() {
        return idpersona;
    }

    
    public void setIdpersona(int idpersona) {
        this.idpersona = idpersona;
    }

    
    public int getCuil() {
        return cuil;
    }

    
    public void setCuil(int cuil) {
        this.cuil = cuil;
    }

   
    public String getNombre() {
        return nombre;
    }

    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

   
    public String getApellido() {
        return apellido;
    }

    
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    
    public Date getF_nacim() {
        return f_nacim;
    }

   
    public void setF_nacim(Date f_nacim) {
        this.f_nacim = f_nacim;
    }

    
    public String getEmail() {
        return email;
    }

    
    public void setEmail(String email) {
        this.email = email;
    }

    
    public String getTelefono1() {
        return telefono1;
    }

    
    public void setTelefono1(String telefono1) {
        this.telefono1 = telefono1;
    }

    
    public String getTelefono2() {
        return telefono2;
    }

    
    public void setTelefono2(String telefono2) {
        this.telefono2 = telefono2;
    }

    
    public String getTelefono3() {
        return telefono3;
    }

    
    public void setTelefono3(String telefono3) {
        this.telefono3 = telefono3;
    }

    
    public int getIddominio() {
        return iddominio;
    }

    
    public void setIddominio(int iddominio) {
        this.iddominio = iddominio;
    }

    
    public int getIdcochera() {
        return idcochera;
    }

    
    public void setIdcochera(int idcochera) {
        this.idcochera = idcochera;
    }
 
    
    public Direccion getDireccion() {
        return direccion;
    }

    
    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return "Cliente{" + "idpersona=" + idpersona + ", cuil=" + cuil + ", nombre=" + nombre + ", apellido=" + apellido + ", f_nacim=" + f_nacim + ", email=" + email + ", telefono1=" + telefono1 + ", telefono2=" + telefono2 + ", telefono3=" + telefono3 + ", direccion=" + direccion + ", iddominio=" + iddominio + ", idcochera=" + idcochera + '}';
    }
   
}
