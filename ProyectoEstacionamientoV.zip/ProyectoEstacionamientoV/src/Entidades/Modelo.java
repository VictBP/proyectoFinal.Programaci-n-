
package Entidades;


public class Modelo {
    
     private int idmodelo;
   private Marca marca;
   private String descripcion;
   private Tipo tipo;

    
    public int getIdmodelo() {
        return idmodelo;
    }

    
    public void setIdmodelo(int idmodelo) {
        this.idmodelo = idmodelo;
    }

    
    public Marca getMarca() {
        return marca;
    }

    
    public void setMarca(Marca marca) {
        this.marca = marca;
    }

    
    public String getDescripcion() {
        return descripcion;
    }

    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    
    public Tipo getTipo() {
        return tipo;
    }

    
    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public Modelo(){
    }

    @Override
    public String toString() {
        return "Modelo{" + "idmodelo=" + idmodelo + ", marca=" + marca + ", descripcion=" + descripcion + ", tipo=" + tipo + '}';
    }

}
