
package Entidades;


public class Provincia {
    private int idprovincia;
    private String nombre;
    private String abreviatura;

    
    public int getIdprovincia() {
        return idprovincia;
    }

   
    public void setIdprovincia(int idprovincia) {
        this.idprovincia = idprovincia;
    }

    
    public String getNombre() {
        return nombre;
    }

    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return nombre ;
    }
    
    
    public Provincia(){
    }

   
    public String getAbreviatura() {
        return abreviatura;
    }

    
    public void setAbreviatura(String abreviatura) {
        this.abreviatura = abreviatura;
    }
}
