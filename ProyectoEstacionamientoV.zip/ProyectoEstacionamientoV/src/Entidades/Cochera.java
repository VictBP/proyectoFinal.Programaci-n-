package Entidades;


public class Cochera {
    private int idcochera;
    private String numcochera;
    private boolean ocupado;
    private int idvehiculo;

  
    public int getIdcochera() {
        return idcochera;
    }

  
    public void setIdcochera(int idcohera) {
        this.idcochera = idcohera;
    }

    
    public String getNumcochera() {
        return numcochera;
    }

    public void setNumcochera(String numcochera) {
        this.numcochera = numcochera;
    }


    public boolean isOcupado() {
        return ocupado;
    }

   
    public void setOcupado(boolean ocupado) {
        this.ocupado = ocupado;
    }

   
    public int getIdvehiculo() {
        return idvehiculo;
    }

    
    public void setIdvehiculo(int idvehiculo) {
        this.idvehiculo = idvehiculo;
    }

    @Override
    public String toString() {
        return getNumcochera();
    }
    
}
