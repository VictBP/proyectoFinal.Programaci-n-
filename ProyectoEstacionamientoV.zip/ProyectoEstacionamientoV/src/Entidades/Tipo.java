
package Entidades;


public class Tipo {
    
    private int idtipo;
 private String Descripcion;

    
    public int getIdtipo() {
        return idtipo;
    }

    
    public void setIdtipo(int idtipo) {
        this.idtipo = idtipo;
    }

    
    public String getDescripcion() {
        return Descripcion;
    }

    
    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }
    
    public Tipo(){
    }

    @Override
    public String toString() {
        return "Tipo{" + "idtipo=" + idtipo + ", Descripcion=" + Descripcion + '}';
    }

}
