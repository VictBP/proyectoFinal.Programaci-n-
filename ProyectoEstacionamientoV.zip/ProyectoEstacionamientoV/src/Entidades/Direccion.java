
package Entidades;


public class Direccion {
    
    private int iddireccion;
    private String calle;
    private int numero;
    private int piso;
    private String departamento;
    private String cp;
    private Localidad localidad;
    private Provincia provincia;

    
    public int getIddireccion() {
        return iddireccion;
    }

    
    public void setIddireccion(int iddireccion) {
        this.iddireccion = iddireccion;
    }

    
    public String getCalle() {
        return calle;
    }

    
    public void setCalle(String calle) {
        this.calle = calle;
    }

   
    public int getNumero() {
        return numero;
    }

    
    public void setNumero(int numero) {
        this.numero = numero;
    }

    
    public int getPiso() {
        return piso;
    }

   
    public void setPiso(int piso) {
        this.piso = piso;
    }

    
    public String getDepartamento() {
        return departamento;
    }

    
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    
    public String getCp() {
        return cp;
    }

    
    public void setCp(String cp) {
        this.cp = cp;
    }

    
    public Localidad getLocalidad() {
        return localidad;
    }

    
    public void setLocalidad(Localidad localidad) {
        this.localidad = localidad;
    }

  
    public Provincia getProvincia() {
        return provincia;
    }

   
    public void setProvincia(Provincia provincia) {
        this.provincia = provincia;
    }

    @Override
    public String toString() {
        return "Direccion{" + "iddireccion=" + iddireccion + ", calle=" + calle + ", numero=" + numero + ", piso=" + piso + ", departamento=" + departamento + ", cp=" + cp + ", localidad=" + localidad + ", provincia=" + provincia + '}';
    }
}
