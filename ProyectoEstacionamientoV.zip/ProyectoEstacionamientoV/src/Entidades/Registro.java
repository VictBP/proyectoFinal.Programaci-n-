
package Entidades;

import java.sql.Time;
import java.util.Date;

public class Registro {
    
    private int idregistro;
    private String patente;
    private String titular;
    private Date fecha;
    private Time hora;
    private boolean ES;

    
    public int getIdregistro() {
        return idregistro;
    }

    
    public void setIdregistro(int idregistro) {
        this.idregistro = idregistro;
    }

    
    public String getPatente() {
        return patente;
    }

    
    public void setPatente(String patente) {
        this.patente = patente;
    }

    
    public String getTitular() {
        return titular;
    }

    
    public void setTitular(String titular) {
        this.titular = titular;
    }

    
    public Date getFecha() {
        return fecha;
    }

    
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    
    public Time getHora() {
        return hora;
    }

    
    public void setHora(Time hora) {
        this.hora = hora;
    }

    
    public boolean isES() {
        return ES;
    }

    
    public void setES(boolean ES) {
        this.ES = ES;
    }

    @Override
    public String toString() {
        return "Registro{" + "idregistro=" + idregistro + ", patente=" + patente + ", titular=" + titular + ", fecha=" + fecha + ", hora=" + hora + ", ES=" + ES + '}';
    }
    
}
