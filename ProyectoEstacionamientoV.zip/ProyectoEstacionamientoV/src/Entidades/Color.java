
package Entidades;


public class Color {
    
    private int idcolor;
    private String descripcion;

    
    public int getIdcolor() {
        return idcolor;
    }

    
    public String getDescripcion() {
        return descripcion;
    }

   
    public void setIdcolor(int idcolor) {
        this.idcolor = idcolor;
    }

    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Color(){
    }

    @Override
    public String toString() {
        return "Color{" + "idcolor=" + idcolor + ", descripcion=" + descripcion + '}';
    }

}
