
package Entidades;

public class Localidad {
    private Double idlocalidad;
    private String nombre;
    private String departamento;
    private Provincia provincia;

   
    
    public String getNombre() {
        return nombre;
    }

    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

   
    public Localidad(){
    }

    @Override
    public String toString() {
        return nombre;
    }

    
    public String getDepartamento() {
        return departamento;
    }

    
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    
    public void setIdlocalidad(Double idlocalidad) {
        this.idlocalidad = idlocalidad;
    }

    
    public Double getIdlocalidad() {
        return idlocalidad;
    }

      
    public Provincia getProvincia() {
        return provincia;
    }

    
    public void setProvincia(Provincia provincia) {
        this.provincia = provincia;
    }
    
    
    
}