
package Entidades;


public class Usuario {
    
    private int idusuario;
    private String nombre;
    private int DNI;
    private String password;
    private boolean borrado;
  
public Usuario(){
} 

    public int getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    
    public boolean isBorrado() {
        return borrado;
    }

    
    public void setBorrado(boolean borrado) {
        this.borrado = borrado;
    }

    
}

